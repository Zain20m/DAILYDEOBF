# 2hbj deobfuscation tools – instructions

## Requirements
- Node.js (any recent version; no npm packages needed, the parser is bundled)
- Python 3 with lupa:  `pip install lupa`

## Run
    bash tools/run.sh <obfuscated.lua> <workdir>

Example:
    bash tools/run.sh samples/7fd4d337-2hbj_888878.lua work

Results appear in `<workdir>`:
- `out.lua`            – decompiled script (the real script is at the bottom;
                         everything above it is the obfuscator's anti-tamper)
- `stage2.lua`         – the VM wrapper, formatted, with its strings decrypted
- `disasm.txt`         – raw VM disassembly
- `handlers_used.txt`  – one handler body per VM opcode

## What each step does
1. `pre.js`       converts Luau-only literals (0b..., 1_000) to plain Lua
2. `beautify.js`  parses to an AST (bundled luaparse, patched for `continue` and `+=`)
3. `stage2.js`    folds constants and decrypts the wrapper's strings
4. `instr.py`     inserts dump hooks into the VM
5. `dump.py`      runs only the VM loader under LuaJIT and writes `dump.json`
                  (the protected script itself is never executed)
6. `handlers.js`  isolates the code for each opcode
7. `disasm.py`    disassembles
8. `emit.py`      (uses `decomp.py`) removes junk, rebuilds control flow, prints Lua

## Using it on a different file from the same obfuscator
The tools are tuned to the included sample. For another file, three places
need updating by hand:
- `stage2.js`  – the base85 alphabet (`yp`), the order table (`Qd`) and the
                 function names `NE`, `ju`, `UQ`, `gX`
- `instr.py`   – the four code snippets it searches for use this sample's
                 variable names (`ld`, `Ca`, `Zb`, `jQ`, ...)
- `disasm.py`  – the `OPS` table (opcode number -> meaning). Run up to
                 `handlers.js`, read `handlers_used.txt`, and fill it in.
If a step fails with an assertion, that is the place that needs updating.
