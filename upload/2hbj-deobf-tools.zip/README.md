# FulcrumDeobf

Deobfuscation of a Luau script protected with "2hbj's obfuscator" (a custom
register VM with encrypted, rolling-key bytecode and injected anti-tamper).

## Result

| File | What it is |
| --- | --- |
| `output/7fd4d337-2hbj_888878.deobf.lua` | Decompiled payload (read the header comment first) |
| `output/7fd4d337-2hbj_888878.vm_wrapper.lua` | The VM wrapper, formatted, constants folded, its own strings decrypted |
| `output/7fd4d337-2hbj_888878.vm_disasm.txt` | Raw disassembly of all 100 VM prototypes |

## How it works

`tools/run.sh <input.lua> <workdir>` runs the whole pipeline (needs `node` and
`python3` with `lupa`):

1. `pre.js`, `beautify.js`, `gen.js`, `stage2.js` – parse the Luau source,
   fold constant arithmetic, decrypt the wrapper's string table.
2. `instr.py`, `dump.py` – run only the VM's loader under LuaJIT and dump the
   decrypted prototypes, constants and opcode tables. The payload is never
   executed.
3. `handlers.js` – partially evaluate the dispatch trees to get one handler
   body per opcode.
4. `disasm.py`, `decomp.py`, `emit.py` – disassemble, strip junk (opaque
   predicates, dead stores, unreachable code), rebuild control flow and print
   Lua source.

## Limits

The tools are tuned to this sample. `stage2.js` and `instr.py` match the
wrapper's identifier names and base85 alphabet, and the opcode table in
`disasm.py` was mapped by hand from `handlers_used.txt`. Another file from the
same obfuscator will need those three places updated.

`tools/luaparse_luau.js` is luaparse (MIT) with `continue` and compound
assignment added.
