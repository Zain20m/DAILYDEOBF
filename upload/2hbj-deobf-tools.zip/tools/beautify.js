const luaparse=require('./luaparse_luau.js'),fs=require('fs');
const src=fs.readFileSync(process.argv[2],'latin1');
const ast=luaparse.parse(src,{luaVersion:'5.3',ranges:false});
fs.writeFileSync(process.argv[3],JSON.stringify(ast));
console.log('parsed ok', ast.body.length);
