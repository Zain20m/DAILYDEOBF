"""Decompiler for the 2hbj-obfuscator VM bytecode (Lua 5.1-like register machine)."""
import sys, math, struct
import disasm

sys.setrecursionlimit(100000)

COND = ('EQ', 'EQK', 'LT', 'LE', 'LTK', 'TEST')
ARITH_RR = {'ADD': '+', 'SUB': '-', 'MUL': '*', 'DIV': '/', 'MOD': '%', 'POW': '^', 'XOR': 'xor'}
ARITH_RK = {'ADDK': '+', 'MULK': '*', 'DIVK': '/', 'MODK': '%', 'XORK': 'xor'}
ARITH_KK = {'ADDKK': '+', 'SUBKK': '-', 'MULKK': '*', 'XORKK': 'xor'}
NAC = ('nac',)


def sbx(ins):
    return ins[2] * 256 + ins[3] - 32767


# ---------------------------------------------------------------- constant folding
def isnum(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def norm(v):
    if isinstance(v, float) and v == v and abs(v) < 2 ** 53 and v == int(v):
        return int(v)
    return v


def fold_bin(op, a, b):
    """returns (ok, value)"""
    try:
        if op == '..':
            if isinstance(a, bytes) and isinstance(b, bytes):
                return True, a + b
            return False, None
        if op in ('==', '~='):
            if isinstance(a, bool) != isinstance(b, bool):
                eq = False
            else:
                eq = (a == b)
            return True, eq if op == '==' else not eq
        if op in ('<', '<='):
            if isnum(a) and isnum(b):
                return True, (a < b if op == '<' else a <= b)
            return False, None
        if not (isnum(a) and isnum(b)):
            return False, None
        if op == '+':
            return True, norm(a + b)
        if op == '-':
            return True, norm(a - b)
        if op == '*':
            return True, norm(a * b)
        if op == '/':
            if b == 0:
                return False, None
            return True, norm(a / b)
        if op == '%':
            if b == 0:
                return False, None
            return True, norm(a - math.floor(a / b) * b)
        if op == '^':
            return True, norm(float(a) ** float(b))
        if op == 'xor':
            if a != int(a) or b != int(b):
                return False, None
            return True, (int(a) % 4294967296) ^ (int(b) % 4294967296)
    except Exception:
        pass
    return False, None


def truthy(v):
    return not (v is None or v is False)


# ---------------------------------------------------------------- per-proto analysis
class Fn:
    def __init__(self, q, P):
        self.q = q
        self.P = P
        self.id = q['id']
        self.k = q['k']
        self.ins = [list(x) for x in q['ins']]
        self.n = len(self.ins)
        self.nparams = q['nparams']
        self.orig = [list(x) for x in q['ins']]
        self.captured = set()
        self.upwritten = set()
        self.closure_caps = {}   # ci -> set(regs captured by the closure created there)
        self.capt_reach = {}     # reg -> set(instrs reachable from a capture point)

    def reset(self):
        self.ins = [list(x) for x in self.orig]

    def set_captures(self, caps, upwritten):
        """caps: dict ci -> set(regs)"""
        self.closure_caps = caps
        self.upwritten = upwritten
        self.captured = set()
        self.capt_reach = {}
        for ci, regs in caps.items():
            if not regs:
                continue
            seen = set()
            st = list(self.succ(ci))
            while st:
                i = st.pop()
                if i in seen or i < 0 or i >= self.n:
                    continue
                seen.add(i)
                st.extend(self.succ(i))
            for r in regs:
                self.captured.add(r)
                self.capt_reach.setdefault(r, set()).update(seen)

    def is_capt(self, i, r):
        return i in self.capt_reach.get(r, ())

    def K(self, i):
        return self.k[i] if i < len(self.k) else None

    # ---- successors
    def succ(self, i):
        op, a, b, c = self.ins[i]
        if op == 'JMP':
            return [i + 1 + sbx(self.ins[i])]
        if op == 'RETURN':
            return []
        if op in COND:
            return [i + 1, i + 2]
        if op == 'CMPJ':  # fused cond+jmp: a=cond tuple, b=target
            return [b, i + 1]
        if op == 'LOADBOOL':
            return [i + 2] if c else [i + 1]
        if op in ('FORPREP', 'TFORPREP'):
            return [i + 1 + sbx(self.ins[i])]
        if op in ('FORLOOP', 'TFORLOOP'):
            return [i + 1 + sbx(self.ins[i]), i + 1]
        return [i + 1]

    def reachable(self):
        seen = set()
        st = [0]
        while st:
            i = st.pop()
            if i in seen or i < 0 or i >= self.n:
                continue
            seen.add(i)
            st.extend(self.succ(i))
        return seen

    # ---- uses / defs
    def du(self, i):
        op, a, b, c = self.ins[i]
        R = lambda x, y: list(range(x, y))
        if op == 'CLOSURE':
            return sorted(self.closure_caps.get(i, ())), [a]
        if op in ('LOADK', 'GETGLOBAL', 'GETUPVAL', 'NEWTABLE'):
            return [], [a]
        if op == 'LOADBOOL':
            return [], [a]
        if op == 'LOADNIL':
            return [], R(a, b + 1)
        if op == 'MOVE':
            return [b], [a]
        if op in ('SETGLOBAL', 'SETUPVAL'):
            return [a], []
        if op == 'GETTABLE':
            return [b, c], [a]
        if op == 'SETTABLE':
            return [a, b, c], []
        if op in ARITH_RR:
            return [b, c], [a]
        if op in ARITH_RK:
            return [b], [a]
        if op in ARITH_KK:
            return [], [a]
        if op in ('NOT', 'UNM', 'LEN'):
            return [b], [a]
        if op == 'CONCAT':
            return R(b, c + 1), [a]
        if op in ('EQ', 'LT', 'LE'):
            return [b, c], []
        if op in ('EQK', 'LTK'):
            return [b], []
        if op == 'TEST':
            return [a], []
        if op == 'CMPJ':
            return list(a[2]), []
        if op == 'CMPBOOL':
            return list(a[2]), [b]
        if op in ('JMP', 'NEWFRAME', 'TFOREND', 'NOP'):
            return [], []
        if op in ('CALL', 'CALLV'):
            if op == 'CALLV':
                uses = R(a, a + b + 1)
            elif b > 0:
                uses = R(a, a + b)
            else:
                uses = R(a, self.mstart[i] + 1)
            if c == 1:
                defs = []
            elif c == 0:
                defs = [a]
            else:
                defs = R(a, a + c - 1)
            return uses, defs
        if op == 'RETURN':
            if b > 0:
                return R(a, a + b - 1), []
            return R(a, self.mstart[i] + 1), []
        if op == 'VARARG':
            return [], [a]
        if op == 'SHIFT':
            return [b], [a]
        if op == 'SETLIST':
            return R(a, a + b + 1), [a]
        if op == 'FORPREP':
            return [a, a + 1, a + 2], []
        if op == 'FORLOOP':
            return [], [a + 3]
        if op == 'TFORPREP':
            return [a, a + 1, a + 2], []
        if op == 'TFORLOOP':
            return [], [a + 3, a + 4]
        raise Exception('du ' + op)

    def compute_mstart(self):
        self.mstart = {}
        m = None
        for i in range(self.n):
            op, a, b, c = self.ins[i]
            if op in ('CALL', 'RETURN') and b == 0 and op != 'CALLV':
                self.mstart[i] = m if m is not None else a
            if op in ('CALL', 'CALLV', 'VARARG') and c == 0:
                m = a
            elif op == 'SHIFT':
                m = a

    # ---- pattern: cond; JMP->i+3; LOADBOOL A 1 1; LOADBOOL A 0 0   =>  CMPBOOL
    def cond_tuple(self, i):
        """condition under which the JMP following cond instr i is taken: (op, negate, regs, kconst)"""
        op, a, b, c = self.ins[i]
        if op == 'EQ':
            return ('==', a == 0, (b, c), None)
        if op == 'EQK':
            return ('==', a == 0, (b,), ('k', self.K(c)))
        if op == 'LT':
            return ('<', a == 0, (b, c), None)
        if op == 'LE':
            return ('<=', a == 0, (b, c), None)
        if op == 'LTK':
            return ('<', a == 0, (b,), ('k', self.K(c)))
        if op == 'TEST':
            return ('truthy', c == 0, (a,), None)
        raise Exception(op)

    def fuse(self):
        reach = self.reachable()
        targets = {}
        for i in reach:
            for s in self.succ(i):
                targets.setdefault(s, set()).add(i)
        for i in sorted(reach):
            op = self.ins[i][0]
            if op in COND:
                assert self.ins[i + 1][0] == 'JMP', (self.id, i, self.ins[i + 1])
                tgt = i + 2 + sbx(self.ins[i + 1])
                ct = self.cond_tuple(i)
                l1 = self.ins[i + 2] if i + 2 < self.n else None
                l2 = self.ins[i + 3] if i + 3 < self.n else None
                if (tgt == i + 3 and l1 and l2 and l1[0] == 'LOADBOOL' and l2[0] == 'LOADBOOL' and l1[1] == l2[1]
                        and l1[2] == 1 and l1[3] == 1 and l2[2] == 0 and l2[3] == 0
                        and targets.get(i + 3, set()) <= {i + 1} and targets.get(i + 2, set()) <= {i}
                        and targets.get(i + 1, set()) <= {i}):
                    # jump taken -> false ; not taken -> true   => value = not cond
                    ct2 = (ct[0], not ct[1], ct[2], ct[3])
                    self.ins[i] = ['CMPBOOL', ct2, l1[1], 0]
                    self.ins[i + 1] = ['NOP', 0, 0, 0]
                    self.ins[i + 2] = ['NOP', 0, 0, 0]
                    self.ins[i + 3] = ['NOP', 0, 0, 0]
                else:
                    self.ins[i] = ['CMPJ', ct, tgt, 0]
                    self.ins[i + 1] = ['NOP', 0, 0, 0] if targets.get(i + 1, set()) <= {i} else self.ins[i + 1]

    # ---- constant propagation
    def eval_cond(self, ct, vals):
        op, neg, regs, kc = ct
        ops = [vals.get(r, None) for r in regs]
        if any(o is None or o is NAC for o in ops):
            return None
        ops = [o[1] for o in ops]
        if kc is not None:
            ops.append(kc[1])
        if op == 'truthy':
            r = truthy(ops[0])
        else:
            ok, r = fold_bin(op, ops[0], ops[1])
            if not ok:
                return None
        return (not r) if neg else r

    def constprop(self):
        """forward dataflow; returns dict i -> resolved bool for CMPJ, and dict of CMPBOOL consts"""
        n = self.n
        IN = {0: {}}
        work = [0]
        nacregs = self.upwritten
        self_ = self
        resolved = {}

        def meet(a, b):
            out = {}
            for r in set(a) | set(b):
                x = a.get(r)
                y = b.get(r)
                if x is None or y is None:
                    out[r] = NAC  # undefined on one path: be conservative
                elif x == y and type(x[1] if x is not NAC else 0) == type(y[1] if y is not NAC else 0):
                    out[r] = x
                else:
                    out[r] = NAC
            return out

        inq = {0}
        while work:
            i = work.pop()
            inq.discard(i)
            if i < 0 or i >= n:
                continue
            vals = dict(IN[i])
            op, a, b, c = self.ins[i]
            succs = self.succ(i)

            def setv(r, v):
                vals[r] = NAC if (r in nacregs and self_.is_capt(i, r)) else v

            def getc(r):
                v = vals.get(r)
                if v is None or v is NAC:
                    return None
                return v

            if op == 'LOADK':
                setv(a, ('c', self.K(b * 256 + c)) if b * 256 + c < len(self.k) else NAC)
            elif op == 'LOADBOOL':
                setv(a, ('c', b != 0))
            elif op == 'LOADNIL':
                for r in range(a, b + 1):
                    setv(r, ('c', None))
            elif op == 'MOVE':
                v = vals.get(b)
                setv(a, v if v is not None else NAC)
            elif op in ARITH_RR or op in ARITH_RK or op in ARITH_KK:
                if op in ARITH_RR:
                    x, y, o = getc(b), getc(c), ARITH_RR[op]
                elif op in ARITH_RK:
                    x, y, o = getc(b), ('c', self.K(c)), ARITH_RK[op]
                else:
                    x, y, o = ('c', self.K(b)), ('c', self.K(c)), ARITH_KK[op]
                if x and y:
                    ok, r = fold_bin(o, x[1], y[1])
                    setv(a, ('c', r) if ok else NAC)
                else:
                    setv(a, NAC)
            elif op == 'NOT':
                x = getc(b)
                setv(a, ('c', not truthy(x[1])) if x else NAC)
            elif op == 'UNM':
                x = getc(b)
                setv(a, ('c', norm(-x[1])) if x and isnum(x[1]) else NAC)
            elif op == 'LEN':
                x = getc(b)
                setv(a, ('c', len(x[1])) if x and isinstance(x[1], bytes) else NAC)
            elif op == 'CONCAT':
                xs = [getc(r) for r in range(b, c + 1)]
                if all(x and isinstance(x[1], bytes) for x in xs):
                    setv(a, ('c', b''.join(x[1] for x in xs)))
                else:
                    setv(a, NAC)
            elif op == 'CMPBOOL':
                r = self.eval_cond(a, vals)
                setv(b, ('c', r) if r is not None else NAC)
            elif op == 'CMPJ':
                r = self.eval_cond(a, vals)
                if r is not None:
                    if i in resolved and resolved[i] != r:
                        resolved[i] = None
                    elif i not in resolved:
                        resolved[i] = r
                    if resolved[i] is not None:
                        succs = [b] if r else [i + 1]
                else:
                    resolved[i] = None
            else:
                uses, defs = self.du(i)
                for r in defs:
                    vals[r] = NAC
                if op == 'CLOSURE':
                    for r in self.closure_caps.get(i, ()):
                        if r in nacregs:
                            vals[r] = NAC
                if op in ('CALL', 'CALLV') and c == 0:
                    for r in list(vals):
                        if r >= a:
                            vals[r] = NAC
            for s in succs:
                if s < 0 or s >= n:
                    continue
                if s not in IN:
                    IN[s] = vals
                    ch = True
                else:
                    m = meet(IN[s], vals)
                    ch = m != IN[s]
                    IN[s] = m
                if ch and s not in inq:
                    inq.add(s)
                    work.append(s)
        changed = False
        for i, r in resolved.items():
            if r is None:
                continue
            op, a, b, c = self.ins[i]
            if r:
                self.ins[i] = ['JMP', 0, 0, 0]
                self._setjmp(i, b)
            else:
                self.ins[i] = ['NOP', 0, 0, 0]
            changed = True
        self.constin = IN
        return changed

    def _setjmp(self, i, target):
        v = target - (i + 1) + 32767
        self.ins[i] = ['JMP', 0, v // 256, v % 256]

    # ---- liveness / dead store elimination
    PURE = ('LOADK', 'GETGLOBAL', 'GETUPVAL', 'CLOSURE', 'NEWTABLE', 'LOADBOOL', 'LOADNIL', 'MOVE', 'NOT', 'CMPBOOL',
            'XOR', 'XORK', 'XORKK', 'ADDKK', 'SUBKK', 'MULKK', 'ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'POW', 'ADDK', 'MULK',
            'DIVK', 'MODK', 'UNM', 'LEN', 'CONCAT', 'VARARG', 'GETTABLE')

    def liveness(self):
        reach = sorted(self.reachable())
        self.compute_mstart()
        live_in = {i: set() for i in reach}
        succs = {i: [s for s in self.succ(i) if 0 <= s < self.n] for i in reach}
        dus = {i: self.du(i) for i in reach}
        changed = True
        while changed:
            changed = False
            for i in reversed(reach):
                out = set()
                for s in succs[i]:
                    out |= live_in[s]
                u, d = dus[i]
                new = (out - set(d)) | set(u)
                if new != live_in[i]:
                    live_in[i] = new
                    changed = True
        live_out = {}
        for i in reach:
            out = set()
            for s in succs[i]:
                out |= live_in[s]
            live_out[i] = out
        return reach, live_out, dus

    def is_pure(self, i, strict_vals=None):
        op, a, b, c = self.ins[i]
        if op not in self.PURE:
            return False
        if op in ('ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'POW', 'ADDK', 'MULK', 'DIVK', 'MODK', 'UNM', 'LEN', 'CONCAT',
                  'GETTABLE', 'XOR', 'XORK'):
            # only pure if operands are known constants of the right type (cannot error)
            vals = self.constin.get(i, {})
            for r in self.du(i)[0]:
                v = vals.get(r)
                if v is None or v is NAC:
                    return False
                if op == 'GETTABLE':
                    return False
                if op in ('CONCAT',) and not isinstance(v[1], (bytes, int, float)):
                    return False
                if op == 'LEN' and not isinstance(v[1], bytes):
                    return False
                if op not in ('CONCAT', 'LEN') and not isnum(v[1]):
                    return False
            return True
        if op == 'LOADBOOL' and c:
            return False  # control flow; handled separately
        return True

    def dse(self):
        reach, live_out, dus = self.liveness()
        changed = False
        for i in reach:
            op, a, b, c = self.ins[i]
            u, d = dus[i]
            if op == 'MOVE' and a == b:
                self.ins[i] = ['NOP', 0, 0, 0]
                changed = True
                continue
            if not d:
                continue
            if any(r in live_out[i] or self.is_capt(i, r) for r in d):
                continue
            if op == 'LOADBOOL' and c:
                self._setjmp(i, i + 2)
                changed = True
                continue
            if self.is_pure(i):
                self.ins[i] = ['NOP', 0, 0, 0]
                changed = True
        return changed

    def simplify(self):
        self.compute_mstart()
        self.fuse()
        for _ in range(50):
            self.compute_mstart()
            c1 = self.constprop()
            c2 = self.dse()
            if not (c1 or c2):
                break
        self.compute_mstart()
        self.constprop()

    # ---- basic blocks
    def build_blocks(self):
        reach = self.reachable()
        # skip NOPs when resolving targets
        def skip(i):
            while i < self.n and self.ins[i][0] == 'NOP':
                i += 1
            return i
        self.skip = skip
        leaders = {skip(0)}
        for i in reach:
            op = self.ins[i][0]
            if op == 'NOP':
                continue
            ss = self.succ(i)
            if op in ('JMP', 'RETURN', 'CMPJ', 'FORPREP', 'TFORPREP', 'FORLOOP', 'TFORLOOP') or (op == 'LOADBOOL' and self.ins[i][3]):
                for s in ss:
                    leaders.add(skip(s))
                leaders.add(skip(i + 1))
        for i in reach:
            if self.ins[i][0] in ('FORLOOP', 'TFORLOOP'):
                leaders.add(i)
        live = [i for i in sorted(reach) if self.ins[i][0] != 'NOP']
        blocks = {}
        cur = None
        for i in live:
            if i in leaders or cur is None:
                cur = i
                blocks[cur] = []
            blocks[cur].append(i)
        self.blocks = blocks
        self.bsucc = {}
        for b, lst in blocks.items():
            last = lst[-1]
            op = self.ins[last][0]
            ss = [skip(s) for s in self.succ(last)]
            self.bsucc[b] = [s for s in ss if s in blocks]
        self.entry = skip(0)
        self.block_of = {}
        for b, lst in blocks.items():
            for i in lst:
                self.block_of[i] = b
        self.bpred = {b: [] for b in blocks}
        for b, ss in self.bsucc.items():
            for s in ss:
                self.bpred[s].append(b)

    # ---- reaching definitions -> webs
    def build_webs(self):
        self.compute_mstart()
        blocks = self.blocks
        order = sorted(blocks)
        dus = {}
        for b in order:
            for i in blocks[b]:
                dus[i] = self.du(i)
        self.dus = dus
        allregs = set()
        for i, (u, d) in dus.items():
            allregs |= set(u) | set(d)
        allregs |= set(range(self.nparams)) | self.captured
        # captured registers: defs reachable from the capture point belong to the captured variable
        capt_defs = []
        # IN[b]: reg -> frozenset of def sites
        IN = {b: {} for b in order}
        IN[self.entry] = {r: frozenset([(-1, r)]) for r in allregs}
        OUT = {}

        def transfer(b, inn):
            cur = dict(inn)
            for i in blocks[b]:
                for r in dus[i][1]:
                    cur[r] = frozenset([(i, r)])
            return cur

        changed = True
        while changed:
            changed = False
            for b in order:
                if b != self.entry:
                    inn = {}
                    for p in self.bpred[b]:
                        if p in OUT:
                            for r, s in OUT[p].items():
                                inn[r] = inn[r] | s if r in inn else s
                    if inn != IN[b]:
                        IN[b] = inn
                        changed = True
                o = transfer(b, IN[b])
                if OUT.get(b) != o:
                    OUT[b] = o
                    changed = True
        parent = {}

        def find(x):
            while parent.setdefault(x, x) != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            x, y = find(x), find(y)
            if x != y:
                parent[y] = x

        use_defs = {}
        for b in order:
            cur = dict(IN[b])
            for i in blocks[b]:
                for r in dus[i][0]:
                    ds = cur.get(r) or frozenset([(-1, r)])
                    use_defs[(i, r)] = ds
                    first = None
                    for dd in ds:
                        find(dd)
                        if first is None:
                            first = dd
                        else:
                            union(first, dd)
                for r in dus[i][1]:
                    find((i, r))
                    cur[r] = frozenset([(i, r)])
        for r in allregs:
            find((-1, r))
        for ci, regs in self.closure_caps.items():
            if (ci, None) not in dus and ci not in dus:
                continue
            for r in regs:
                ds = use_defs.get((ci, r))
                if not ds:
                    continue
                w = next(iter(ds))
                seen = set()
                st = list(self.succ(ci))
                while st:
                    j = st.pop()
                    if j in seen or j < 0 or j >= self.n:
                        continue
                    seen.add(j)
                    st.extend(self.succ(j))
                for j in seen:
                    if j in dus and r in dus[j][1]:
                        union(w, (j, r))
        self.find = find
        self.use_defs = use_defs
        # web stats
        self.web_defs = {}
        self.web_uses = {}
        for dsite in list(parent):
            self.web_defs.setdefault(find(dsite), []).append(dsite)
        for (i, r), ds in use_defs.items():
            w = find(next(iter(ds)))
            self.web_uses.setdefault(w, []).append((i, r))

    def web_of_use(self, i, r):
        ds = self.use_defs.get((i, r))
        if not ds:
            return self.find((-1, r))
        return self.find(next(iter(ds)))

    def web_of_def(self, i, r):
        return self.find((i, r))

    def inlinable(self, i, r):
        """def (i,r) is a single-def single-use temp within the same block"""
        w = self.find((i, r))
        if self.is_capt(i, r):
            return False
        defs = [d for d in self.web_defs.get(w, []) if d[0] != -1 or d[1] < self.nparams]
        real_defs = [d for d in self.web_defs.get(w, [])]
        # entry pseudo-def counts only if some use is reached by it
        uses = self.web_uses.get(w, [])
        if len(uses) != 1:
            return False
        ds = self.use_defs[uses[0]]
        if ds != frozenset([(i, r)]):
            return False
        ui = uses[0][0]
        if self.block_of[ui] != self.block_of[i] or ui <= i:
            return False
        return True


# ================================================================ AST construction
TRUE = ('k', True)


def K(v):
    return ('k', v)


def ekind(e):
    t = e[0]
    if t in ('k', 'closure', 'vararg0'):
        return 0
    if t in ('call', 'mcall', 'vararg'):
        return 2
    if t == 'var' or t == 'global':
        return 1
    m = 1
    for x in e[1:]:
        if isinstance(x, tuple) and x and isinstance(x[0], str):
            m = max(m, ekind(x))
        elif isinstance(x, (list, tuple)):
            for y in x:
                if isinstance(y, tuple) and y and isinstance(y[0], str):
                    m = max(m, ekind(y))
    return m


def mkbin(op, x, y):
    if x[0] == 'k' and y[0] == 'k':
        ok, r = fold_bin(op, x[1], y[1])
        if ok:
            return K(r)
    if op == 'xor':
        return ('call', ('index', ('global', b'bit32'), K(b'bxor')), [x, y])
    return ('bin', op, x, y)


def negate(e):
    if e[0] == 'un' and e[1] == 'not':
        return e[2]
    if e[0] == 'bin' and e[1] == '==':
        return ('bin', '~=', e[2], e[3])
    if e[0] == 'bin' and e[1] == '~=':
        return ('bin', '==', e[2], e[3])
    if e[0] == 'k':
        return K(not truthy(e[1]))
    return ('un', 'not', e)


class Loop:
    def __init__(self, cont, brk):
        self.cont = cont
        self.brk = brk


def build_ast(self, F):
    """self: Fn"""
    ins = self.ins
    # jump threading over trivial blocks
    def thread(b):
        seen = set()
        while b in self.blocks and len(self.blocks[b]) == 1 and ins[self.blocks[b][0]][0] == 'JMP' and b not in seen:
            seen.add(b)
            b = self.bsucc[b][0] if self.bsucc[b] else b
        return b
    self.thread = thread
    succ = {b: [thread(s) for s in ss] for b, ss in self.bsucc.items()}
    entry = thread(self.entry)
    # DFS: back edges, rpo
    color = {}
    back = set()
    post = []
    stack = [(entry, iter(succ[entry]))]
    color[entry] = 1
    while stack:
        b, it = stack[-1]
        adv = False
        for s in it:
            if color.get(s, 0) == 0:
                color[s] = 1
                stack.append((s, iter(succ[s])))
                adv = True
                break
            elif color[s] == 1:
                back.add((b, s))
        if not adv:
            color[b] = 2
            post.append(b)
            stack.pop()
    rpo = {b: i for i, b in enumerate(reversed(post))}
    preds = {b: [] for b in rpo}
    for b in rpo:
        for s in succ[b]:
            preds[s].append(b)
    headers = {}
    for (t, h) in back:
        nodes = headers.setdefault(h, {h})
        st = [t]
        while st:
            x = st.pop()
            if x in nodes:
                continue
            nodes.add(x)
            st.extend(preds[x])
    fwd = {b: [s for s in succ[b] if (b, s) not in back] for b in rpo}

    def reach(b, stops):
        out = set()
        st = [b]
        while st:
            x = st.pop()
            if x in out or x in stops:
                continue
            out.add(x)
            st.extend(fwd[x])
        return out

    def find_follow(t, f, stops):
        r1 = reach(t, stops)
        r2 = reach(f, stops)
        common = r1 & r2
        if not common:
            return None
        return min(common, key=lambda x: rpo[x])

    emitted = set()
    labels = set()
    self.labels = labels
    warnings = []
    self.warnings = warnings

    def var_use(i, r):
        return ('var', (self.id, self.web_of_use(i, r)))

    def var_def(i, r):
        return ('var', (self.id, self.web_of_def(i, r)))

    def upvar(depth, r):
        ch = self
        anc = self
        for _ in range(depth):
            ch = anc
            anc = F[anc.q['parent']]
        ci = anc.creator.get(ch.id)
        if ci is None or (ci, r) not in anc.use_defs:
            return ('var', (anc.id, anc.find((-1, r))))
        return ('var', (anc.id, anc.web_of_use(ci, r)))

    def emit_block(b):
        stmts = []
        pending = {}

        def use(i, r):
            p = pending.get(r)
            if p is not None and self.use_defs.get((i, r)) == frozenset([(p[1], r)]):
                del pending[r]
                return p[0]
            return var_use(i, r)

        def materialize(r):
            e, di = pending.pop(r)
            stmts.append(['assign', [var_def(di, r)], [e]])

        def flush():
            for r in sorted(pending, key=lambda r: pending[r][1]):
                if ekind(pending[r][0]) > 0:
                    materialize(r)

        def uses(i, regs):
            # order check
            idxs = [pending[r][1] for r in regs if r in pending and ekind(pending[r][0]) > 1
                    and self.use_defs.get((i, r)) == frozenset([(pending[r][1], r)])]
            if idxs != sorted(idxs):
                for r in sorted(set(regs), key=lambda r: pending[r][1] if r in pending else -1):
                    if r in pending and ekind(pending[r][0]) > 0:
                        materialize(r)
            return [use(i, r) for r in regs]

        def define(i, r, e):
            if self.inlinable(i, r):
                pending[r] = (e, i)
                return
            w = self.web_of_def(i, r)
            nuses = len(self.web_uses.get(w, []))
            flush()
            if nuses == 0 and not self.is_capt(i, r):
                if e[0] in ('call', 'mcall'):
                    stmts.append(['call', e])
                elif ekind(e) > 0:
                    stmts.append(['assign', [var_def(i, r)], [e]])
                return
            stmts.append(['assign', [var_def(i, r)], [e]])

        def mkcall(f, args):
            if f[0] == 'index' and f[2][0] == 'k' and isinstance(f[2][1], bytes) and args and args[0] == f[1] and ekind(f[1]) <= 1 and f[1][0] == 'var':
                return ('mcall', f[1], f[2][1], args[1:])
            return ('call', f, args)

        term = None
        lst = self.blocks[b]
        for i in lst:
            op, a, bb, c = ins[i]
            if op == 'LOADK':
                define(i, a, K(self.K(bb * 256 + c)))
            elif op == 'LOADBOOL':
                define(i, a, K(bb != 0))
                if c:
                    term = ('jmp', thread(self.skip(i + 2)))
            elif op == 'LOADNIL':
                for r in range(a, bb + 1):
                    define(i, r, K(None))
            elif op == 'MOVE':
                define(i, a, use(i, bb))
            elif op == 'GETGLOBAL':
                define(i, a, ('global', self.K(bb * 256 + c)))
            elif op == 'SETGLOBAL':
                v = use(i, a)
                flush()
                stmts.append(['assign', [('global', self.K(bb * 256 + c))], [v]])
            elif op == 'GETUPVAL':
                define(i, a, upvar(bb, c))
            elif op == 'SETUPVAL':
                v = use(i, a)
                flush()
                stmts.append(['assign', [upvar(bb, c)], [v]])
            elif op == 'GETTABLE':
                x, y = uses(i, [bb, c])
                define(i, a, ('index', x, y))
            elif op == 'SETTABLE':
                t, k, v = uses(i, [a, bb, c])
                flush()
                stmts.append(['assign', [('index', t, k)], [v]])
            elif op in ARITH_RR:
                x, y = uses(i, [bb, c])
                define(i, a, mkbin(ARITH_RR[op], x, y))
            elif op in ARITH_RK:
                x = use(i, bb)
                define(i, a, mkbin(ARITH_RK[op], x, K(self.K(c))))
            elif op in ARITH_KK:
                define(i, a, mkbin(ARITH_KK[op], K(self.K(bb)), K(self.K(c))))
            elif op == 'NOT':
                x = use(i, bb)
                define(i, a, K(not truthy(x[1])) if x[0] == 'k' else ('un', 'not', x))
            elif op == 'UNM':
                x = use(i, bb)
                define(i, a, K(norm(-x[1])) if x[0] == 'k' and isnum(x[1]) else ('un', '-', x))
            elif op == 'LEN':
                x = use(i, bb)
                define(i, a, K(len(x[1])) if x[0] == 'k' and isinstance(x[1], bytes) else ('un', '#', x))
            elif op == 'CONCAT':
                xs = uses(i, list(range(bb, c + 1)))
                e = xs[-1]
                for x in reversed(xs[:-1]):
                    e = mkbin('..', x, e)
                # left-assoc fold of constants
                define(i, a, e)
            elif op == 'CMPBOOL':
                cop, neg, regs, kc = a
                xs = uses(i, list(regs))
                if kc is not None:
                    xs.append(K(kc[1]))
                if cop == 'truthy':
                    e = ('un', 'not', xs[0]) if neg else ('un', 'not', ('un', 'not', xs[0]))
                else:
                    e = mkbin(cop, xs[0], xs[1])
                    if neg:
                        e = negate(e)
                define(i, bb, e)
            elif op == 'CMPJ':
                cop, neg, regs, kc = a
                xs = uses(i, list(regs))
                if kc is not None:
                    xs.append(K(kc[1]))
                e = xs[0] if cop == 'truthy' else mkbin(cop, xs[0], xs[1])
                if neg:
                    e = negate(e)
                flush()
                term = ('cond', e, thread(self.skip(bb)), thread(self.skip(i + 1)))
            elif op == 'JMP':
                term = ('jmp', thread(self.skip(i + 1 + sbx(ins[i]))))
            elif op in ('CALL', 'CALLV'):
                if op == 'CALLV':
                    regs = list(range(a, a + bb + 1))
                elif bb > 0:
                    regs = list(range(a, a + bb))
                else:
                    regs = list(range(a, self.mstart[i] + 1))
                xs = uses(i, regs)
                if op == 'CALLV':
                    xs.append(('vararg',))
                e = mkcall(xs[0], xs[1:])
                if c == 1:
                    flush()
                    stmts.append(['call', e])
                elif c == 0:
                    if self.inlinable(i, a):
                        pending[a] = (e, i)
                    else:
                        warnings.append('multi-call not inlined at %d' % i)
                        define(i, a, e)
                elif c == 2:
                    define(i, a, e)
                else:
                    flush()
                    stmts.append(['assign', [var_def(i, r) for r in range(a, a + c - 1)], [e]])
            elif op == 'VARARG':
                if c == 0:
                    if self.inlinable(i, a):
                        pending[a] = (('vararg',), i)
                    else:
                        warnings.append('multi-vararg not inlined at %d' % i)
                        define(i, a, ('vararg',))
                else:
                    define(i, a, ('paren', ('vararg',)))
            elif op == 'SHIFT':
                if bb in pending:
                    e, di = pending.pop(bb)
                    pending[a] = (e, i)
                else:
                    warnings.append('shift of non-pending at %d' % i)
                    define(i, a, use(i, bb))
            elif op == 'RETURN':
                regs = list(range(a, a + bb - 1)) if bb > 0 else list(range(a, self.mstart[i] + 1))
                xs = uses(i, regs)
                flush()
                stmts.append(['return', xs])
                term = ('ret',)
            elif op == 'CLOSURE':
                define(i, a, ('closure', self.q['children'][bb * 256 + c]))
            elif op == 'NEWTABLE':
                define(i, a, ('table', []))
            elif op == 'SETLIST':
                xs = uses(i, list(range(a, a + bb + 1)))
                if xs[0][0] == 'table' and not xs[0][1]:
                    define(i, a, ('table', [(None, x) for x in xs[1:]]))
                else:
                    flush()
                    for n, x in enumerate(xs[1:]):
                        stmts.append(['assign', [('index', xs[0], K(n + 1))], [x]])
                    define(i, a, xs[0])
            elif op == 'FORPREP':
                xs = uses(i, [a, a + 1, a + 2])
                flush()
                L = i + 1 + sbx(ins[i])
                term = ('fornum', var_def(L, a + 3), xs, self.block_of[self.skip(i + 1)], L, thread(self.skip(L + 1)))
            elif op == 'TFORPREP':
                xs = uses(i, [a, a + 1, a + 2])
                flush()
                L = i + 1 + sbx(ins[i])
                term = ('forin', [var_def(L, a + 3), var_def(L, a + 4)], xs, self.block_of[self.skip(i + 1)], L, thread(self.skip(L + 1)))
            elif op in ('NEWFRAME', 'TFOREND', 'NOP'):
                pass
            else:
                raise Exception('emit ' + op)
        for r in sorted(pending, key=lambda r: pending[r][1]):
            materialize(r)
        if term is None:
            nxt = self.skip(lst[-1] + 1)
            term = ('jmp', thread(nxt)) if nxt in self.blocks else ('ret',)
        return stmts, term

    def region(b, follow, loop, outer, skipcheck=False, loophead=None):
        stmts = []
        while True:
            if b is None or b not in self.blocks:
                break
            if not skipcheck:
                if b == follow:
                    break
                if loop and b == loop.cont:
                    stmts.append(['continue'])
                    break
                if loop and b == loop.brk:
                    stmts.append(['break'])
                    break
                if b in emitted or b in outer:
                    stmts.append(['goto', b])
                    labels.add(b)
                    break
            if b in headers and b != loophead and ins[self.blocks[b][0]][0] not in ('FORLOOP', 'TFORLOOP'):
                nodes = headers[b]
                exits = set()
                for x in nodes:
                    for s in succ[x]:
                        if s not in nodes:
                            exits.add(s)
                mx = max(nodes)
                after = [e for e in exits if e > mx]
                Fl = min(after) if after else (min(exits) if exits else None)
                body = region(b, None, Loop(b, Fl), outer | ({follow} if follow is not None else set()) | ({loop.cont, loop.brk} if loop else set()), True, b)
                stmts.append(['while', TRUE, body])
                b = Fl
                skipcheck = False
                continue
            skipcheck = False
            emitted.add(b)
            stmts.append(['label', b])
            ss, term = emit_block(b)
            stmts.extend(ss)
            if term[0] == 'jmp':
                b = term[1]
            elif term[0] == 'ret':
                break
            elif term[0] == 'cond':
                _, e, T, Fb = term
                stops = set(outer)
                if follow is not None:
                    stops.add(follow)
                if loop:
                    stops.add(loop.cont)
                    if loop.brk is not None:
                        stops.add(loop.brk)
                fol = find_follow(T, Fb, stops) if T != Fb else T
                if fol is not None:
                    o2 = outer | ({follow} if follow is not None else set())
                    then = region(Fb, fol, loop, o2)
                    els = region(T, fol, loop, o2)
                    stmts.append(['if', negate(e), then, els])
                    b = fol
                else:
                    then = region(Fb, follow, loop, outer)
                    els = region(T, follow, loop, outer)
                    stmts.append(['if', negate(e), then, els])
                    break
            elif term[0] in ('fornum', 'forin'):
                _, v, xs, body_entry, L, ex = term
                Lb = self.block_of[L]
                o2 = outer | ({follow} if follow is not None else set()) | ({loop.cont, loop.brk} if loop else set())
                o2.discard(None)
                emitted.add(Lb)
                body = region(thread(body_entry), None, Loop(Lb, ex), o2)
                if term[0] == 'fornum':
                    stmts.append(['fornum', v, xs, body])
                else:
                    stmts.append(['forin', v, xs, body])
                b = ex
        return stmts

    self.ast = region(entry, None, None, set())
    return self.ast
