import json,sys
OPS={233:'LOADK',78:'LOADK',169:'MOVE',182:'MOVE',97:'JMP',92:'LOADBOOL',104:'CALL',227:'LOADNIL',179:'LOADNIL',183:'EQ',189:'XOR',95:'XOR',
242:'GETGLOBAL',77:'GETGLOBAL',201:'TEST',147:'RETURN',68:'CONCAT',246:'CONCAT',32:'GETTABLE',82:'GETTABLE',115:'EQK',34:'GETUPVAL',58:'GETUPVAL',
67:'SETTABLE',238:'LT',46:'LE',15:'LTK',48:'SUB',113:'SUB',156:'ADD',96:'ADD',133:'ADD',108:'MUL',186:'MUL',172:'DIV',66:'MOD',13:'MOD',211:'MOD',
162:'POW',26:'POW',111:'MODK',21:'ADDK',73:'MULK',130:'DIVK',100:'XORK',116:'ADDKK',207:'SUBKK',109:'XORKK',7:'MULKK',121:'NOT',174:'NOT',94:'UNM',
249:'LEN',212:'LEN',19:'CLOSURE',225:'CLOSURE',102:'CLOSURE',69:'SETUPVAL',220:'SETUPVAL',237:'NEWTABLE',44:'NEWTABLE',139:'VARARG',244:'SETGLOBAL',12:'SETGLOBAL',
1:'SHIFT',164:'FORPREP',196:'FORLOOP',22:'NEWFRAME',83:'CALLV',105:'TFORPREP',241:'TFORLOOP',253:'TFOREND',229:'SETLIST',127:'SETLIST'}
def konst(k):
    if k is None: return None
    if 's' in k: return bytes.fromhex(k['s'])
    if 'n' in k:
        f=float(k['n']); return int(f) if f==int(f) and abs(f)<2**53 else f
    return k['b']
def load(path='dump.json'):
    d=json.load(open(path)); protos=[]
    def walk(p,parent):
        idx=len(protos); q={'id':idx,'parent':parent,'k':[konst(k) for k in p['k']],'nparams':p['nparams'],'vararg':p['vararg'],'children':[],'ins':[]}
        protos.append(q)
        for i in range(len(p['op'])):
            op=OPS[p['xx'][i]]; a,b,c=p['a'][i],p['b'][i],p['c'][i]
            q['ins'].append([op,a,b,c])
        for ch in p['protos']: q['children'].append(walk(ch,idx))
        return idx
    walk(d['main'],None); return protos
class KL(list):
    def __getitem__(s,i):
        return list.__getitem__(s,i) if i<len(s) else '<<OOB>>'
def fmt(q,i):
    op,a,b,c=q['ins'][i]; K=KL(q['k']); bx=b*256+c
    if op in('LOADK','GETGLOBAL','SETGLOBAL'): return f'{op} r{a} K{bx}={K[bx]!r}'
    if op in('JMP','FORPREP','FORLOOP','TFORPREP','TFORLOOP'): return f'{op} r{a} -> {i+2+bx-32767}'
    if op=='CLOSURE': return f'{op} r{a} proto#{q["children"][bx]}'
    if op in('EQK','LTK','MODK','ADDK','MULK','DIVK','XORK'): return f'{op} {a} r{b} K{c}={K[c]!r}'
    if op in('ADDKK','SUBKK','XORKK','MULKK'): return f'{op} r{a} K{b}={K[b]!r} K{c}={K[c]!r}'
    return f'{op} {a} {b} {c}'
if __name__=='__main__':
    P=load()
    with open('disasm.txt','w') as f:
        for q in P:
            f.write(f'\n== proto {q["id"]} parent={q["parent"]} nparams={q["nparams"]} vararg={q["vararg"]} children={q["children"]}\n')
            for i in range(len(q['ins'])): f.write(f'{i+1:5d}  {fmt(q,i)}\n')
