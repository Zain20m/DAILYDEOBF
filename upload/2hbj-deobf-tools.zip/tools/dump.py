import sys,json,lupa.luajit21 as L
lua=L.LuaRuntime(unpack_returned_tuples=True,encoding=None)
lua.execute(open('shim.lua','rb').read())
lua.globals()[b'SRC']=open('instr.lua','rb').read()
r=lua.execute(rb'''
local f,err=loadstring(SRC,"=obf") if not f then return "LOADERR "..tostring(err) end
local out={}
local function esc(s) return (s:gsub(".",function(c) return string.format("%02x",c:byte()) end)) end
local function js(s) return '"'..(tostring(s):gsub('[%c"\\\128-\255]',function(c) return string.format("\\u%04x",c:byte()) end))..'"' end
local function jv(v) if type(v)=="number" and v==v and v~=1/0 and v~=-1/0 then return string.format("%.17g",v) elseif type(v)=="boolean" then return tostring(v) end return js(v) end
local function arr(t,from,to) local r={} for i=from,to do local v=t[i] r[#r+1]= v==nil and "null" or jv(v) end return "["..table.concat(r,",").."]" end
local function dumpP(p,un)
  local K=un[p.dI+1]
  local n=p[K.JN] or 0
  local ks={}
  local cs=p[K.vu]
  for i=0,n-1 do local v=cs[i] local t=type(v)
    if t=="string" then ks[#ks+1]='{"s":"'..esc(v)..'"}' elseif t=="number" then ks[#ks+1]='{"n":"'..string.format("%.17g",v)..'"}' elseif t=="boolean" then ks[#ks+1]='{"b":'..tostring(v)..'}' else ks[#ks+1]='null' end end
  local ops=p[K.Qe][K.hF] local N=#ops
  local ch={}
  for i=0,(p[K.bS] or 0)-1 do ch[#ch+1]=dumpP(p[K.Nh][i],un) end
  local extra={}
  for k,v in pairs(p) do if type(v)~="table" then extra[#extra+1]=js(k)..':'..js(v) end end
  return '{"k":['..table.concat(ks,",")..'],"xx":'..arr(p.XX,1,N)..',"raw":'..arr(p.RAW,1,N)..',"op":'..arr(ops,1,N)..',"a":'..arr(p[K.jv][K.BC],1,N)..',"b":'..arr(p[K.Dg][K.Tu],1,N)..',"c":'..arr(p[K.UR][K.ny],1,N)
    ..',"vararg":'..tostring(p[K.Ah] and true or false)..',"nparams":'..tostring(p[K.RW])..',"f":{'..table.concat(extra,",")..'},"protos":['..table.concat(ch,",")..']}'
end
DUMPHOOK=function(Io,un,qw,ek,QX,kC,Ec)
  local function m(t) local r={} for k,v in pairs(t) do r[#r+1]=js(k)..':'..jv(v) end return "{"..table.concat(r,",").."}" end
  out[#out+1]='{"qw":'..arr(qw,1,#qw)..',"ek":'..arr(ek,1,256)..',"QX":'..m(QX)..',"kC":'..m(kC)..',"Ec":'..m(Ec)..',"main":'..dumpP(Io,un)..'}'
  error("DUMPED",0)
end
local ok,e=pcall(f)
if not out[1] then return "FAIL "..tostring(e) end
return out[1] or ("FAIL "..tostring(e))
''')
if not r.startswith(b'{'):
    sys.exit('dump failed: ' + r.decode('latin1'))
open('dump.json','wb').write(r)
d=json.loads(r)
def walk(p,depth=0):
    print('  '*depth,len(p['op']),'ins',len(p['k']),'consts',p['nparams'],p['vararg'],p['f'])
    for c in p['protos']: walk(c,depth+1)
walk(d['main'])
print(len(d['qw']),d['qw'][:20])
