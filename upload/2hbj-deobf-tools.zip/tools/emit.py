"""AST cleanup, scoping and Lua source printing for decomp.py output."""
import re, sys
import disasm, decomp
from decomp import K, TRUE, negate, ekind, truthy

TERM = ('return', 'break', 'continue', 'goto')
KW = set('and break do else elseif end false for function if in local nil not or repeat return then true until while continue'.split())


# ---------------------------------------------------------------- generic walkers
def sub_exprs(e):
    t = e[0]
    if t in ('k', 'var', 'global', 'vararg', 'closure'):
        return []
    if t == 'index':
        return [e[1], e[2]]
    if t == 'bin':
        return [e[2], e[3]]
    if t == 'un':
        return [e[2]]
    if t == 'paren':
        return [e[1]]
    if t == 'call':
        return [e[1]] + list(e[2])
    if t == 'mcall':
        return [e[1]] + list(e[3])
    if t == 'table':
        out = []
        for k, v in e[1]:
            if k is not None:
                out.append(k)
            out.append(v)
        return out
    raise Exception('sub_exprs ' + t)


def map_expr(e, fn):
    """bottom-up rewrite"""
    t = e[0]
    if t == 'index':
        e = ('index', map_expr(e[1], fn), map_expr(e[2], fn))
    elif t == 'bin':
        e = ('bin', e[1], map_expr(e[2], fn), map_expr(e[3], fn))
    elif t == 'un':
        e = ('un', e[1], map_expr(e[2], fn))
    elif t == 'paren':
        e = ('paren', map_expr(e[1], fn))
    elif t == 'call':
        e = ('call', map_expr(e[1], fn), [map_expr(x, fn) for x in e[2]])
    elif t == 'mcall':
        e = ('mcall', map_expr(e[1], fn), e[2], [map_expr(x, fn) for x in e[3]])
    elif t == 'table':
        e = ('table', [(map_expr(k, fn) if k is not None else None, map_expr(v, fn)) for k, v in e[1]])
    return fn(e)


def stmt_exprs(s):
    """header expressions of a statement (not nested blocks), in evaluation order"""
    t = s[0]
    if t == 'assign':
        out = []
        for tg in s[1]:
            if tg[0] == 'index':
                out += [tg[1], tg[2]]
        return out + list(s[2])
    if t == 'local':
        return list(s[2])
    if t == 'call':
        return [s[1]]
    if t == 'return':
        return list(s[1])
    if t in ('if', 'while'):
        return [s[1]]
    if t == 'repeat':
        return [s[2]]
    if t in ('fornum', 'forin'):
        return list(s[2])
    return []


def stmt_blocks(s):
    t = s[0]
    if t == 'if':
        return [s[2], s[3]]
    if t == 'while':
        return [s[2]]
    if t == 'repeat':
        return [s[1]]
    if t in ('fornum', 'forin'):
        return [s[3]]
    return []


def map_stmt_exprs(s, fn):
    t = s[0]
    if t == 'assign':
        s[1] = [map_expr(x, fn) if x[0] == 'index' else x for x in s[1]]
        s[2] = [map_expr(x, fn) for x in s[2]]
    elif t == 'local':
        s[2] = [map_expr(x, fn) for x in s[2]]
    elif t == 'call':
        s[1] = map_expr(s[1], fn)
    elif t == 'return':
        s[1] = [map_expr(x, fn) for x in s[1]]
    elif t in ('if', 'while'):
        s[1] = map_expr(s[1], fn)
    elif t == 'repeat':
        s[2] = map_expr(s[2], fn)
    elif t in ('fornum', 'forin'):
        s[2] = [map_expr(x, fn) for x in s[2]]


def walk_stmts(stmts, fn):
    for s in stmts:
        fn(s)
        for b in stmt_blocks(s):
            walk_stmts(b, fn)


# ---------------------------------------------------------------- cleanup
def ends_term(b):
    return bool(b) and b[-1][0] in TERM


def has_continue(stmts):
    for s in stmts:
        if s[0] == 'continue':
            return True
        if s[0] == 'if' and (has_continue(s[2]) or has_continue(s[3])):
            return True
    return False


def strip_tail_continue(b):
    while b and b[-1][0] == 'continue':
        b.pop()
    if b and b[-1][0] == 'if':
        strip_tail_continue(b[-1][2])
        strip_tail_continue(b[-1][3])


def clean(stmts, labels):
    out = []
    for s in stmts:
        t = s[0]
        if t == 'label':
            if s[1] in labels:
                out.append(s)
            continue
        if t == 'if':
            s[2] = clean(s[2], labels)
            s[3] = clean(s[3], labels)
            if not s[2] and s[3]:
                s[1], s[2], s[3] = negate(s[1]), s[3], []
            if not s[2] and not s[3]:
                if ekind(s[1]) >= 2:
                    out.append(['assign', [('global', b'_')], [s[1]]])
                continue
            if s[1][0] == 'k':
                out.extend(s[2] if truthy(s[1][1]) else s[3])
                continue
            if s[3]:
                if ends_term(s[2]):
                    els = s[3]
                    s[3] = []
                    out.append(s)
                    out.extend(els)
                    continue
                if ends_term(s[3]):
                    then = s[2]
                    s[1], s[2], s[3] = negate(s[1]), s[3], []
                    out.append(s)
                    out.extend(then)
                    continue
            out.append(s)
            continue
        if t in ('while', 'fornum', 'forin'):
            bi = 2 if t == 'while' else 3
            body = clean(s[bi], labels)
            strip_tail_continue(body)
            body = clean(body, labels)
            s[bi] = body
            if t == 'while' and s[1] == TRUE:
                if body and body[0][0] == 'if' and body[0][2] == [['break']] and not body[0][3]:
                    s[1] = negate(body[0][1])
                    s[2] = body[1:]
                elif body and body[-1][0] == 'if' and body[-1][2] == [['break']] and not body[-1][3] and not has_continue(body):
                    s = ['repeat', body[:-1], body[-1][1]]
            out.append(s)
            continue
        out.append(s)
    # drop unreachable statements after a terminator
    for i, s in enumerate(out):
        if s[0] in TERM and i + 1 < len(out) and out[i + 1][0] != 'label':
            j = i + 1
            while j < len(out) and out[j][0] != 'label':
                j += 1
            out = out[:i + 1] + out[j:]
            break
    return out


def andor(stmts):
    """if c then v = A else v = B end  ->  v = c and A or B (only safe forms)"""
    for i, s in enumerate(stmts):
        for b in stmt_blocks(s):
            andor(b)
        if s[0] == 'if' and len(s[2]) == 1 and len(s[3]) == 1:
            a, b = s[2][0], s[3][0]
            if a[0] == 'assign' and b[0] == 'assign' and len(a[1]) == 1 and a[1] == b[1] and a[1][0][0] == 'var' and len(a[2]) == 1 and len(b[2]) == 1:
                c, A, B = s[1], a[2][0], b[2][0]
                v = a[1]
                if A == c:
                    stmts[i] = ['assign', v, [('bin', 'or', c, B)]]
                elif B == c:
                    stmts[i] = ['assign', v, [('bin', 'and', c, A)]]
                elif c[0] == 'un' and c[1] == 'not' and A == c[2]:
                    stmts[i] = ['assign', v, [('bin', 'and', c[2], B)]]
                elif c[0] == 'un' and c[1] == 'not' and B == c[2]:
                    stmts[i] = ['assign', v, [('bin', 'or', c[2], A)]]


# ---------------------------------------------------------------- AST-level temp inlining
class Prog:
    def __init__(self, F):
        self.F = F

    def count_vars(self):
        cnt = {}
        incl = set()  # vars occurring inside a closure other than their owner

        def ce(e, fid):
            t = e[0]
            if t == 'var':
                cnt[e[1]] = cnt.get(e[1], 0) + 1
                if e[1][0] != fid:
                    incl.add(e[1])
            elif t == 'closure':
                pass
            else:
                for x in sub_exprs(e):
                    ce(x, fid)

        for f in self.F:
            def st(s, f=f):
                if s[0] in ('assign', 'local'):
                    for tg in s[1]:
                        if tg[0] == 'var':
                            ce(tg, f.id)
                if s[0] == 'fornum':
                    ce(s[1], f.id)
                if s[0] == 'forin':
                    for v in s[1]:
                        ce(v, f.id)
                for e in stmt_exprs(s):
                    ce(e, f.id)
            walk_stmts(f.ast, st)
        return cnt, incl


def first_event(e):
    """first non-constant thing evaluated in e: returns ('var', v) / 'other' / None"""
    t = e[0]
    if t in ('k', 'closure'):
        return None
    if t == 'var':
        return e
    if t in ('global', 'vararg'):
        return 'other'
    if t == 'bin' and e[1] in ('and', 'or'):
        r = first_event(e[2])
        return r if r is not None else 'other'
    for x in sub_exprs(e):
        r = first_event(x)
        if r is not None:
            return r
    return 'other'


def contains_var(e, v):
    if e[0] == 'var':
        return e[1] == v
    if e[0] == 'closure':
        return False
    return any(contains_var(x, v) for x in sub_exprs(e))


def inline_pass(prog):
    cnt, incl = prog.count_vars()
    changed = [False]

    def do(stmts):
        i = 0
        while i < len(stmts):
            s = stmts[i]
            for b in stmt_blocks(s):
                do(b)
            if (s[0] == 'assign' and len(s[1]) == 1 and s[1][0][0] == 'var' and len(s[2]) == 1 and i + 1 < len(stmts)
                    and cnt.get(s[1][0][1], 0) == 2 and s[1][0][1] not in incl and s[2][0][0] != 'vararg'):
                v = s[1][0][1]
                E = s[2][0]
                n = stmts[i + 1]
                if n[0] in ('while', 'repeat'):
                    i += 1
                    continue
                hdr = stmt_exprs(n)
                tot = sum(1 for e in hdr if contains_var(e, v))
                if tot == 1 and not contains_var(E, v):
                    ok = False
                    k = ekind(E)
                    # find first event over the header
                    fe = None
                    for e in hdr:
                        fe = first_event(e)
                        if fe is not None:
                            break
                    if fe == ('var', v):
                        ok = True
                    elif k == 0:
                        ok = True
                    elif k == 1 and E[0] in ('var', 'un', 'bin', 'k'):
                        # pure-ish read of locals: safe unless header assigns... allow
                        ok = all(x[0] != 'call' for x in [E])
                    if ok:
                        def rep(e):
                            return E if e == ('var', v) else e
                        map_stmt_exprs(n, rep)
                        del stmts[i]
                        changed[0] = True
                        i = max(i - 1, 0)
                        continue
            i += 1

    for f in prog.F:
        do(f.ast)
    return changed[0]


# ---------------------------------------------------------------- scoping
def declare(f, F):
    occ = {}
    loopvars = set()
    params = set(f.find((-1, r)) for r in range(f.nparams))

    def collect_expr(e, path):
        t = e[0]
        if t == 'var':
            if e[1][0] == f.id:
                occ.setdefault(e[1], []).append(path)
        elif t == 'closure':
            def st(s):
                for tg in (s[1] if s[0] in ('assign', 'local') else []):
                    collect_expr(tg, path)
                if s[0] == 'fornum':
                    collect_expr(s[1], path)
                if s[0] == 'forin':
                    for v in s[1]:
                        collect_expr(v, path)
                for x in stmt_exprs(s):
                    collect_expr(x, path)
            walk_stmts(F[e[1]].ast, st)
        else:
            for x in sub_exprs(e):
                collect_expr(x, path)

    def collect(stmts, path):
        for idx, s in enumerate(stmts):
            p = path + ((id(stmts), idx, stmts),)
            if s[0] in ('assign', 'local'):
                for tg in s[1]:
                    collect_expr(tg, p)
            for e in stmt_exprs(s):
                collect_expr(e, p)
            if s[0] == 'fornum':
                loopvars.add(s[1][1])
            if s[0] == 'forin':
                for v in s[1]:
                    loopvars.add(v[1])
            for b in stmt_blocks(s):
                collect(b, p)

    collect(f.ast, ())
    decl = {}
    for v, paths in occ.items():
        if v[1] in params or v in loopvars:
            continue
        d = 0
        while all(len(p) > d for p in paths) and len(set(p[d][0] for p in paths)) == 1:
            d += 1
        if d == 0:
            continue
        d -= 1
        # if all occurrences share the same statement at level d and go deeper, that's fine: declare before it
        blk = paths[0][d][2]
        idx = min(p[d][1] for p in paths)
        decl.setdefault(id(blk), [blk, {}])[1].setdefault(idx, []).append(v)
    for blk, m in decl.values():
        for idx in sorted(m, reverse=True):
            vs = m[idx]
            s = blk[idx]
            if s[0] == 'assign' and all(t[0] == 'var' for t in s[1]) and all(t[1] in vs for t in s[1]) and not any(
                    contains_var_deep(e, t[1], F) for e in s[2] for t in s[1]):
                rest = [v for v in vs if ('var', v) not in s[1]]
                blk[idx] = ['local', s[1], s[2]]
                if rest:
                    blk.insert(idx, ['local', [('var', v) for v in rest], []])
            else:
                blk.insert(idx, ['local', [('var', v) for v in vs], []])


def contains_var_deep(e, v, F):
    if e[0] == 'var':
        return e[1] == v
    if e[0] == 'closure':
        found = [False]

        def st(s):
            for x in stmt_exprs(s):
                if contains_var_deep(x, v, F):
                    found[0] = True
            if s[0] in ('assign', 'local'):
                for tg in s[1]:
                    if contains_var_deep(tg, v, F):
                        found[0] = True
        walk_stmts(F[e[1]].ast, st)
        return found[0]
    return any(contains_var_deep(x, v, F) for x in sub_exprs(e))


# ---------------------------------------------------------------- printing
PREC = {'or': 1, 'and': 2, '<': 3, '>': 3, '<=': 3, '>=': 3, '~=': 3, '==': 3, '..': 4, '+': 5, '-': 5, '*': 6, '/': 6, '%': 6, '^': 8}


def lua_str(b):
    try:
        s = b.decode('utf-8')
        utf = True
    except Exception:
        utf = False
    out = ['"']
    data = b
    i = 0
    while i < len(data):
        c = data[i]
        if c == 34:
            out.append('\\"')
        elif c == 92:
            out.append('\\\\')
        elif c == 10:
            out.append('\\n')
        elif c == 13:
            out.append('\\r')
        elif c == 9:
            out.append('\\t')
        elif 32 <= c < 127:
            out.append(chr(c))
        elif c >= 128 and utf:
            # copy utf-8 sequence
            n = 2 if c < 0xE0 else 3 if c < 0xF0 else 4
            out.append(data[i:i + n].decode('utf-8'))
            i += n
            continue
        else:
            nx = data[i + 1] if i + 1 < len(data) else 0
            out.append('\\%03d' % c if 48 <= nx <= 57 else '\\%d' % c)
        i += 1
    out.append('"')
    return ''.join(out)


def lua_num(v):
    if isinstance(v, int):
        return str(v)
    if v != v:
        return '(0/0)'
    if v == float('inf'):
        return 'math.huge'
    if v == float('-inf'):
        return '-math.huge'
    return repr(v)


class Printer:
    def __init__(self, F):
        self.F = F
        self.names = {}
        self.counter = 0
        self.hints = {}
        self.used = set()

    def name(self, v):
        n = self.names.get(v)
        if n is None:
            h = self.hints.get(v)
            if h and h not in self.used and h not in KW:
                n = h
            elif h:
                k = 2
                while '%s%d' % (h, k) in self.used:
                    k += 1
                n = '%s%d' % (h, k)
            else:
                self.counter += 1
                n = 'v%d' % self.counter
            self.used.add(n)
            self.names[v] = n
        return n

    def expr(self, e, pp=0, ind=0):
        t = e[0]
        if t == 'k':
            v = e[1]
            if v is None:
                return 'nil'
            if v is True:
                return 'true'
            if v is False:
                return 'false'
            if isinstance(v, bytes):
                return lua_str(v)
            if isinstance(v, str):
                return v
            s = lua_num(v)
            return '(%s)' % s if s.startswith('-') and pp > 6 else s
        if t == 'var':
            return self.name(e[1])
        if t == 'global':
            g = e[1]
            if isinstance(g, bytes) and re.match(rb'^[A-Za-z_][A-Za-z0-9_]*$', g) and g.decode() not in KW:
                return g.decode()
            return 'getfenv()[%s]' % self.expr(K(g))
        if t == 'vararg':
            return '...'
        if t == 'paren':
            return '(' + self.expr(e[1], 0, ind) + ')'
        if t == 'index':
            base = self.prefix(e[1], ind)
            k = e[2]
            if k[0] == 'k' and isinstance(k[1], bytes) and re.match(rb'^[A-Za-z_][A-Za-z0-9_]*$', k[1]) and k[1].decode() not in KW:
                return base + '.' + k[1].decode()
            return base + '[' + self.expr(k, 0, ind) + ']'
        if t == 'call':
            return self.prefix(e[1], ind) + '(' + ', '.join(self.expr(x, 0, ind) for x in e[2]) + ')'
        if t == 'mcall':
            return self.prefix(e[1], ind) + ':' + e[2].decode() + '(' + ', '.join(self.expr(x, 0, ind) for x in e[3]) + ')'
        if t == 'bin':
            op = e[1]
            p = PREC[op]
            right = op in ('..', '^')
            s = self.expr(e[2], p + 1 if right else p, ind) + ' ' + op + ' ' + self.expr(e[3], p if right else p + 1, ind)
            return '(' + s + ')' if p < pp else s
        if t == 'un':
            op = e[1]
            a = self.expr(e[2], 7, ind)
            s = ('not ' if op == 'not' else op) + a
            return '(' + s + ')' if pp > 7 else s
        if t == 'table':
            if not e[1]:
                return '{}'
            items = []
            for k, v in e[1]:
                if k is None:
                    items.append(self.expr(v, 0, ind + 1))
                elif k[0] == 'k' and isinstance(k[1], bytes) and re.match(rb'^[A-Za-z_][A-Za-z0-9_]*$', k[1]) and k[1].decode() not in KW:
                    items.append(k[1].decode() + ' = ' + self.expr(v, 0, ind + 1))
                else:
                    items.append('[' + self.expr(k, 0, ind + 1) + '] = ' + self.expr(v, 0, ind + 1))
            one = '{' + ', '.join(items) + '}'
            if len(one) < 90 and '\n' not in one:
                return one
            pad = '    ' * (ind + 1)
            return '{\n' + ',\n'.join(pad + x for x in items) + '\n' + '    ' * ind + '}'
        if t == 'closure':
            return self.func(e[1], ind)
        raise Exception('expr ' + t)

    def prefix(self, e, ind):
        s = self.expr(e, 9, ind)
        if e[0] in ('var', 'global', 'index', 'call', 'mcall', 'paren'):
            return s
        return '(' + s + ')' if not s.startswith('(') else s

    def func(self, fid, ind, header=None):
        f = self.F[fid]
        ps = [self.name((f.id, f.find((-1, r)))) for r in range(f.nparams)]
        if f.q['vararg']:
            ps.append('...')
        out = (header or 'function') + '(' + ', '.join(ps) + ')\n'
        out += self.block(f.ast, ind + 1)
        out += '    ' * ind + 'end'
        return out

    def block(self, stmts, ind):
        pad = '    ' * ind
        out = []
        for s in stmts:
            t = s[0]
            if t == 'local':
                names = ', '.join(self.name(v[1]) for v in s[1])
                if (len(s[1]) == 1 and len(s[2]) == 1 and s[2][0][0] == 'closure'):
                    out.append(pad + self.func(s[2][0][1], ind, 'local function ' + names) + '\n')
                elif s[2]:
                    out.append(pad + 'local ' + names + ' = ' + ', '.join(self.expr(x, 0, ind) for x in s[2]) + '\n')
                else:
                    out.append(pad + 'local ' + names + '\n')
            elif t == 'assign':
                out.append(pad + ', '.join(self.expr(x, 0, ind) for x in s[1]) + ' = ' + ', '.join(self.expr(x, 0, ind) for x in s[2]) + '\n')
            elif t == 'call':
                out.append(pad + self.expr(s[1], 0, ind) + '\n')
            elif t == 'return':
                out.append(pad + 'return' + (' ' + ', '.join(self.expr(x, 0, ind) for x in s[1]) if s[1] else '') + '\n')
            elif t == 'if':
                out.append(pad + 'if ' + self.expr(s[1], 0, ind) + ' then\n')
                out.append(self.block(s[2], ind + 1))
                els = s[3]
                while len(els) == 1 and els[0][0] == 'if':
                    out.append(pad + 'elseif ' + self.expr(els[0][1], 0, ind) + ' then\n')
                    out.append(self.block(els[0][2], ind + 1))
                    els = els[0][3]
                if els:
                    out.append(pad + 'else\n')
                    out.append(self.block(els, ind + 1))
                out.append(pad + 'end\n')
            elif t == 'while':
                out.append(pad + 'while ' + self.expr(s[1], 0, ind) + ' do\n' + self.block(s[2], ind + 1) + pad + 'end\n')
            elif t == 'repeat':
                out.append(pad + 'repeat\n' + self.block(s[1], ind + 1) + pad + 'until ' + self.expr(s[2], 0, ind) + '\n')
            elif t == 'fornum':
                xs = s[2]
                hdr = self.expr(xs[0], 0, ind) + ', ' + self.expr(xs[1], 0, ind)
                if xs[2] != K(1):
                    hdr += ', ' + self.expr(xs[2], 0, ind)
                out.append(pad + 'for ' + self.name(s[1][1]) + ' = ' + hdr + ' do\n' + self.block(s[3], ind + 1) + pad + 'end\n')
            elif t == 'forin':
                out.append(pad + 'for ' + ', '.join(self.name(v[1]) for v in s[1]) + ' in ' + ', '.join(self.expr(x, 0, ind) for x in s[2]) + ' do\n' + self.block(s[3], ind + 1) + pad + 'end\n')
            elif t in ('break', 'continue'):
                out.append(pad + t + '\n')
            elif t == 'goto':
                out.append(pad + 'goto L%d\n' % s[1])
            elif t == 'label':
                out.append(pad + '::L%d::\n' % s[1])
            elif t == 'comment':
                out.append(pad + '-- ' + s[1] + '\n')
            else:
                raise Exception('stmt ' + t)
        return ''.join(out)


def build(path='dump.json'):
    P = disasm.load(path)
    F = [decomp.Fn(q, P) for q in P]
    for f in F:
        f.creator = {}
        for i, x in enumerate(f.orig):
            if x[0] == 'CLOSURE':
                cidx = x[2] * 256 + x[3]
                if cidx < len(f.q['children']):
                    f.creator.setdefault(f.q['children'][cidx], i)
    prev = None
    for rnd in range(10):
        # which protos are alive, and what do they capture
        alive = set()
        def mark(f):
            alive.add(f.id)
            for i in f.reachable():
                x = f.ins[i]
                if x[0] == 'CLOSURE':
                    mark(F[f.q['children'][x[2] * 256 + x[3]]])
        mark(F[0])
        caps = {f.id: {} for f in F}
        upw = {f.id: set() for f in F}
        for f in F:
            if f.id not in alive:
                continue
            for i in f.reachable():
                op, a, b, c = f.ins[i]
                if op in ('GETUPVAL', 'SETUPVAL'):
                    ch = anc = f
                    for _ in range(b):
                        ch = anc
                        anc = F[anc.q['parent']]
                    caps[anc.id].setdefault(anc.creator[ch.id], set()).add(c)
                    if op == 'SETUPVAL':
                        upw[anc.id].add(c)
        state = (sorted(alive), {k: sorted((ci, sorted(v)) for ci, v in d.items()) for k, d in caps.items()})
        if state == prev:
            break
        prev = state
        for f in F:
            f.reset()
            f.set_captures(caps[f.id], upw[f.id])
            f.simplify()
    for f in F:
        f.alive = f.id in alive
        f.build_blocks()
        f.build_webs()
    for f in F:
        decomp.build_ast(f, F)
    return F


def main():
    F = build()
    for f in F:
        for _ in range(3):
            f.ast = clean(f.ast, f.labels)
        andor(f.ast)
    prog = Prog(F)
    for _ in range(30):
        ch = inline_pass(prog)
        for f in F:
            andor(f.ast)
            f.ast = clean(f.ast, f.labels)
        if not ch:
            break
    for f in F:
        declare(f, F)
    pr = Printer(F)
    src = pr.block(F[0].ast, 0)
    open(sys.argv[1] if len(sys.argv) > 1 else 'out.lua', 'w').write(src)
    nl = sum(len(f.labels) for f in F)
    print('lines', src.count('\n'), 'labels', nl, 'warnings', sum(len(f.warnings) for f in F))
    for f in F:
        if f.warnings:
            print(f.id, f.warnings[:5])


if __name__ == '__main__':
    main()
