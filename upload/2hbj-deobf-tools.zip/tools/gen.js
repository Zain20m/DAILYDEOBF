// Lua AST -> pretty source, with constant folding. mode: 'luau' (readable) | 'jit' (runnable on LuaJIT)
const fs=require('fs');
const PREC={'or':1,'and':2,'<':3,'>':3,'<=':3,'>=':3,'~=':3,'==':3,'..':5,'+':6,'-':6,'*':7,'/':7,'//':7,'%':7,'^':10};
const UNPREC=8;
function decodeRaw(raw){ // -> array of bytes
  if(raw[0]=='['){const m=/^\[(=*)\[/.exec(raw);let b=raw.slice(m[0].length,raw.length-m[0].length);if(b[0]=='\n')b=b.slice(1);return [...Buffer.from(b,'utf8')];}
  const s=raw.slice(1,-1),out=[];let i=0;
  while(i<s.length){let c=s[i];
    if(c!='\\'){for(const b of Buffer.from(c,'utf8'))out.push(b);i++;continue;}
    c=s[i+1];i+=2;
    const map={n:10,r:13,t:9,a:7,b:8,f:12,v:11,'\\':92,'"':34,"'":39,'\n':10};
    if(c in map)out.push(map[c]);
    else if(/[0-9]/.test(c)){let d=c;while(d.length<3&&/[0-9]/.test(s[i]||''))d+=s[i++];out.push(parseInt(d,10)&255);}
    else if(c=='x'){out.push(parseInt(s.substr(i,2),16));i+=2;}
    else if(c=='z'){while(/\s/.test(s[i]||''))i++;}
    else if(c=='u'){const e=s.indexOf('}',i);for(const b of Buffer.from(String.fromCodePoint(parseInt(s.slice(i+1,e),16)),'utf8'))out.push(b);i=e+1;}
    else out.push(c.charCodeAt(0));
  }
  return out;
}
function encodeStr(bytes){let o='"';for(let k=0;k<bytes.length;k++){const b=bytes[k];
  if(b==34)o+='\\"';else if(b==92)o+='\\\\';else if(b==10)o+='\\n';else if(b==13)o+='\\r';else if(b==9)o+='\\t';
  else if(b>=32&&b<127)o+=String.fromCharCode(b);
  else {const nx=bytes[k+1];o+='\\'+((nx>=48&&nx<=57)?String(b).padStart(3,'0'):b);}
 }return o+'"';}
function numLit(v){ if(Number.isInteger(v)&&Math.abs(v)<1e15)return String(v); if(v===Infinity)return '(1/0)'; if(v===-Infinity)return '(-1/0)'; if(v!==v)return '(0/0)'; return String(v).replace('e+','e'); }
function isNum(n){return n&&n.type=='NumericLiteral';}
function isStr(n){return n&&n.type=='StringLiteral';}
function mkNum(v){return {type:'NumericLiteral',value:v};}
function mkStr(b){return {type:'StringLiteral',bytes:b};}
function sbytes(n){ if(!n.bytes)n.bytes=decodeRaw(n.raw); return n.bytes; }
// ---- folding ----
function fold(n,opt){
  if(!n||typeof n!='object')return n;
  if(Array.isArray(n)){for(let i=0;i<n.length;i++)n[i]=fold(n[i],opt);return n;}
  for(const k in n){const v=n[k]; if(v&&typeof v=='object')n[k]=fold(v,opt);}
  if(n.type=='StringLiteral')sbytes(n);
  if(n.type=='BinaryExpression'&&isNum(n.left)&&isNum(n.right)){
    const a=n.left.value,b=n.right.value;let r;
    switch(n.operator){case'+':r=a+b;break;case'-':r=a-b;break;case'*':r=a*b;break;case'/':r=a/b;break;case'//':r=Math.floor(a/b);break;
      case'%':r=a-Math.floor(a/b)*b;break;case'^':r=Math.pow(a,b);break;}
    if(r!==undefined&&Number.isFinite(r)&&(Number.isInteger(r)?Math.abs(r)<2**53:true))return mkNum(r);
  }
  if(n.type=='BinaryExpression'&&n.operator=='..'&&isStr(n.left)&&isStr(n.right))return mkStr(sbytes(n.left).concat(sbytes(n.right)));
  if(n.type=='UnaryExpression'&&n.operator=='-'&&isNum(n.argument))return mkNum(-n.argument.value);
  if(n.type=='UnaryExpression'&&n.operator=='#'&&isStr(n.argument))return mkNum(sbytes(n.argument).length);
  if(n.type=='CallExpression'&&opt.charFns&&((n.base.type=='Identifier'&&opt.charFns.has(n.base.name))||(n.base.type=='MemberExpression'&&n.base.base.name=='string'&&n.base.identifier.name=='char'))&&n.arguments.every(a=>isNum(a)&&a.value>=0&&a.value<256))
    return mkStr(n.arguments.map(a=>a.value));
  if(opt.hook){const r=opt.hook(n);if(r)return r;}
  return n;
}
// ---- printing ----
function gen(ast,mode){
  let out=[],ind=0,labelN=0;const loopStack=[];
  const I=()=>'    '.repeat(ind);
  function hasContinue(body){let f=false;(function w(x){if(!x||typeof x!='object'||f)return;if(Array.isArray(x)){x.forEach(w);return;}
     if(x.type=='ContinueStatement'){f=true;return;}
     if(['WhileStatement','RepeatStatement','ForNumericStatement','ForGenericStatement','FunctionDeclaration'].includes(x.type))return;
     for(const k in x)w(x[k]);})(body);return f;}
  function E(n,pp){ // pp: parent precedence
    switch(n.type){
      case'Identifier':return n.name;
      case'NumericLiteral':return n.value<0?'('+numLit(n.value)+')':numLit(n.value);
      case'StringLiteral':return encodeStr(sbytes(n));
      case'BooleanLiteral':return String(n.value);
      case'NilLiteral':return'nil';
      case'VarargLiteral':return'...';
      case'FunctionDeclaration':return F(n,true);
      case'TableConstructorExpression':{
        if(!n.fields.length)return'{}';
        const fs_=n.fields.map(f=>f.type=='TableKey'?'['+E(f.key,0)+'] = '+E(f.value,0):f.type=='TableKeyString'?f.key.name+' = '+E(f.value,0):E(f.value,0));
        const one='{'+fs_.join(', ')+'}';
        if(one.length<100&&!one.includes('\n'))return one;
        ind++;const r='{\n'+fs_.map(x=>I()+x).join(',\n')+'\n';ind--;return r+I()+'}';}
      case'LogicalExpression':case'BinaryExpression':{
        const p=PREC[n.operator];const right=(n.operator=='..'||n.operator=='^');
        if(mode=='jit'&&n.operator=='//'){return 'math.floor('+E(n.left,7)+' / '+E(n.right,8)+')';}
        let s=E(n.left,right?p+1:p)+' '+n.operator+' '+E(n.right,right?p:p+1);
        return p<pp?'('+s+')':s;}
      case'UnaryExpression':{const op=n.operator=='not'?'not ':n.operator;let a=E(n.argument,UNPREC);if(op=='-'&&a[0]=='-')a=' '+a;const s=op+a;return pp>UNPREC?'('+s+')':s;}
      case'MemberExpression':return P(n.base)+n.indexer+n.identifier.name;
      case'IndexExpression':{const ix=n.index;
        if(mode!='raw'&&isStr(ix)){const t=Buffer.from(sbytes(ix)).toString('latin1');if(/^[A-Za-z_][A-Za-z0-9_]*$/.test(t)&&!KW.has(t))return P(n.base)+'.'+t;}
        return P(n.base)+'['+E(ix,0)+']';}
      case'CallExpression':return P(n.base)+'('+n.arguments.map(a=>E(a,0)).join(', ')+')';
      case'TableCallExpression':return P(n.base)+'('+E(n.arguments,0)+')';
      case'StringCallExpression':return P(n.base)+'('+E(n.argument,0)+')';
      default:throw new Error('expr '+n.type);
    }}
  const KW=new Set('and break do else elseif end false for function if in local nil not or repeat return then true until while goto continue'.split(' '));
  function P(n){const s=E(n,99);if(['Identifier','MemberExpression','IndexExpression','CallExpression','TableCallExpression','StringCallExpression'].includes(n.type))return s;return s[0]=='('?s:'('+s+')';}
  function F(n,expr,pre){let h=(pre||'')+'function'+(n.identifier&&!expr?' '+E(n.identifier,0):'')+'('+n.parameters.map(p=>E(p,0)).join(', ')+')\n';
    const save=out;out=[];loopStack.push(null);ind++;B(n.body);ind--;loopStack.pop();const body=out.join('');out=save;return h+body+I()+'end';}
  function B(body){for(const s of body)S(s);}
  function loopBody(body){const hc=mode=='jit'&&hasContinue(body);const lbl=hc?'continue_'+(++labelN):null;loopStack.push(lbl);ind++;
    if(hc){out.push(I()+'do\n');ind++;B(body);ind--;out.push(I()+'end\n');out.push(I()+'::'+lbl+'::\n');}else B(body);ind--;loopStack.pop();}
  function S(n){
    switch(n.type){
      case'LocalStatement':out.push(I()+'local '+n.variables.map(v=>v.name).join(', ')+(n.init.length?' = '+n.init.map(e=>E(e,0)).join(', '):'')+'\n');break;
      case'AssignmentStatement':out.push(I()+n.variables.map(v=>E(v,0)).join(', ')+' = '+n.init.map(e=>E(e,0)).join(', ')+'\n');break;
      case'CallStatement':{let s=E(n.expression,0);out.push(I()+(s[0]=='('?';':'')+s+'\n');break;}
      case'FunctionDeclaration':out.push(I()+F(n,false,n.isLocal?'local ':'')+'\n');break;
      case'ReturnStatement':out.push(I()+'return'+(n.arguments.length?' '+n.arguments.map(e=>E(e,0)).join(', '):'')+'\n');break;
      case'BreakStatement':out.push(I()+'break\n');break;
      case'ContinueStatement':out.push(I()+(mode=='jit'?'goto '+loopStack[loopStack.length-1]:'continue')+'\n');break;
      case'DoStatement':out.push(I()+'do\n');ind++;B(n.body);ind--;out.push(I()+'end\n');break;
      case'WhileStatement':out.push(I()+'while '+E(n.condition,0)+' do\n');loopBody(n.body);out.push(I()+'end\n');break;
      case'RepeatStatement':out.push(I()+'repeat\n');loopBody(n.body);out.push(I()+'until '+E(n.condition,0)+'\n');break;
      case'ForNumericStatement':out.push(I()+'for '+n.variable.name+' = '+E(n.start,0)+', '+E(n.end,0)+(n.step?', '+E(n.step,0):'')+' do\n');loopBody(n.body);out.push(I()+'end\n');break;
      case'ForGenericStatement':out.push(I()+'for '+n.variables.map(v=>v.name).join(', ')+' in '+n.iterators.map(e=>E(e,0)).join(', ')+' do\n');loopBody(n.body);out.push(I()+'end\n');break;
      case'IfStatement':n.clauses.forEach((c,i)=>{
          out.push(I()+(c.type=='IfClause'?'if '+E(c.condition,0)+' then':c.type=='ElseifClause'?'elseif '+E(c.condition,0)+' then':'else')+'\n');ind++;B(c.body);ind--;});
        out.push(I()+'end\n');break;
      case'LabelStatement':out.push(I()+'::'+n.label.name+'::\n');break;
      case'GotoStatement':out.push(I()+'goto '+n.label.name+'\n');break;
      default:throw new Error('stmt '+n.type);
    }}
  B(ast.body);return out.join('');
}
module.exports={fold,gen,decodeRaw,encodeStr,mkNum,mkStr,isNum,isStr,sbytes};
if(require.main===module){
  const ast=JSON.parse(fs.readFileSync(process.argv[2]));const mode=process.argv[4]||'luau';
  fold(ast,{charFns:new Set((process.argv[5]||'').split(',').filter(Boolean))});
  fs.writeFileSync(process.argv[3],gen(ast,mode));
}
