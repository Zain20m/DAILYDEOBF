const fs=require('fs');const G=require('./gen.js');
const d=JSON.parse(fs.readFileSync('dump.json'));const qw=d.qw,ek=d.ek;
const ast=JSON.parse(fs.readFileSync('ast.json'));G.fold(ast,{charFns:new Set(['NE'])});
const fns={};(function w(x){if(!x||typeof x!='object')return;if(Array.isArray(x)){x.forEach(w);return;}
  if(x.type=='FunctionDeclaration'&&x.identifier&&['Xc','rV','Ke','cu'].includes(x.identifier.name))fns[x.identifier.name]=x;for(const k in x)w(x[k]);})(ast);
const order=['Xc','rV','Ke','cu'];
function cval(n,XX){ // constant value of expr or undefined
  if(n.type=='NumericLiteral')return n.value;
  if(n.type=='Identifier'&&n.name=='XX')return XX;
  if(n.type=='IndexExpression'&&n.base.type=='Identifier'&&n.base.name=='qw'&&n.index.type=='NumericLiteral')return qw[n.index.value-1];
  if(n.type=='Identifier'&&n.name=='vq')return 'VQ';
  if(n.type=='NilLiteral')return null;
  if(n.type=='UnaryExpression'&&n.operator=='not'){const v=cond(n.argument,XX);return v===undefined?undefined:!v;}
  if(n.type=='BinaryExpression'||n.type=='LogicalExpression')return cond(n,XX);
}
function cond(n,XX){
  if(n.type=='UnaryExpression'&&n.operator=='not'){const v=cond(n.argument,XX);return v===undefined?undefined:!v;}
  if(n.type=='BinaryExpression'&&['==','~=','<','>','<=','>='].includes(n.operator)){
    const a=cval(n.left,XX),b=cval(n.right,XX);if(a===undefined||b===undefined)return undefined;
    if(a==='VQ'||b==='VQ'){ if((a==='VQ'&&b===null)||(b==='VQ'&&a===null))return n.operator=='~='; return undefined;}
    if(typeof a!='number'||typeof b!='number')return undefined;
    switch(n.operator){case'==':return a==b;case'~=':return a!=b;case'<':return a<b;case'>':return a>b;case'<=':return a<=b;case'>=':return a>=b;}}
  return undefined;}
function isJunkLocal(s){return s.type=='LocalStatement'&&s.init.length>0&&s.init.every(e=>e.type=='NumericLiteral'||(e.type=='TableConstructorExpression'&&e.fields.every(f=>f.value.type=='NumericLiteral')))&&s.variables.length==1;}
function spec(body,XX){const out=[];
  for(const s of body){
    if(s.type=='IfStatement'){let done=false,rest=[];
      for(const c of s.clauses){ if(c.type=='ElseClause'){rest.push(c);continue;}
        const v=cond(c.condition,XX);
        if(v===true){ if(rest.length==0){out.push(...spec(c.body,XX));done=true;} else rest.push({type:'ElseClause',body:c.body}); break;}
        if(v===false)continue; rest.push(c);}
      if(done)continue;
      if(rest.length==0)continue;
      if(rest.length==1&&rest[0].type=='ElseClause'){out.push(...spec(rest[0].body,XX));continue;}
      const cl=rest.map((c,i)=>({type:i==0?'IfClause':(c.type=='ElseClause'?'ElseClause':'ElseifClause'),condition:c.condition,body:spec(c.body,XX)}));
      out.push({type:'IfStatement',clauses:cl});continue;}
    if(s.type=='DoStatement'){out.push(...spec(s.body,XX));continue;}
    if(s.type=='WhileStatement'&&cond(s.condition,XX)===false)continue;
    if(s.type=='ForNumericStatement'&&s.body.every(b=>b.type=='ContinueStatement'||isJunkLocal(b)))continue;
    if(isJunkLocal(s))continue;
    if(s.type=='LocalStatement'&&s.init.length==0){ // junk "local x; x = 5"
      out.push(s);continue;}
    if(s.type=='AssignmentStatement'&&s.variables.length==1&&s.variables[0].type=='IndexExpression'&&s.variables[0].base.name=='vq'&&s.variables[0].index.type=='NumericLiteral'&&s.variables[0].index.value>1000)continue;
    const c=Object.assign({},s);
    for(const k of ['body'])if(Array.isArray(c[k]))c[k]=spec(c[k],XX);
    out.push(c);}
  // remove "local x" + "x = num" junk pairs
  for(let i=0;i<out.length-1;i++){const a=out[i],b=out[i+1];
    if(a.type=='LocalStatement'&&a.init.length==0&&a.variables.length==1&&b.type=='AssignmentStatement'&&b.variables.length==1&&b.variables[0].name==a.variables[0].name&&b.init[0].type=='NumericLiteral'){out.splice(i,2);i--;}}
  return out;}
const res={};
for(const XX of new Set(qw)){const f=fns[order[ek[XX]-1]];if(!f)continue;
  res[XX]=G.gen({body:spec(f.body,XX)},'luau');}
fs.writeFileSync('handlers.json',JSON.stringify(res));
const used={};(function w(p){p.xx.forEach(x=>used[x]=(used[x]||0)+1);p.protos.forEach(w);})(d.main);
let txt='';for(const x of Object.keys(used).sort((a,b)=>used[b]-used[a])){txt+=`=== OP ${x} (count ${used[x]}) fn ${order[ek[x]-1]}\n${res[x]}\n`;}
fs.writeFileSync('handlers_used.txt',txt);console.log(Object.keys(used).length, txt.split('\n').length);
