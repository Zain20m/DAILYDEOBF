import re,sys
s=open('stage2_jit.lua').read()
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(a,s.count(a))
    s=s.replace(a,b)
rep("            local IN = vR and kC[ay] or ay\n","            local IN = vR and kC[ay] or ay\n            jQ.xx = jQ.xx or {}; jQ.xx[Da] = Zb[((IN + VN + Da * 223 + Hr + (yk[Da] * 11 + PY[Da] * 17 + jo[Da] * 19) % 256) % 256 + 512 - ((Da * 223 + Hr) % 256 + (yk[Da] * 11 + PY[Da] * 17 + jo[Da] * 19) % 256)) % 256 + 256 - VN]; jQ.raw = jQ.raw or {}; jQ.raw[Da]=ay\n")
rep("        local fr = {}\n        fr.dI = uI\n","        local fr = {}\n        fr.XX = jQ.xx or {}; fr.RAW = jQ.raw or {}\n        fr.dI = uI\n")
rep("            Ca(Io)\n        end\n        local TM = #RU\n","            Ca(Io)\n            if DUMPHOOK then DUMPHOOK(Io, un, qw, ek, QX, kC, Ec) end\n        end\n        local TM = #RU\n")
rep("            local ps, HP, Zz = lK[tc], EZ[tc], WK[tc]\n","            local ps, HP, Zz = lK[tc], EZ[tc], WK[tc]\n            if TRACEHOOK then TRACEHOOK(Io, tc, XX, ps, HP, Zz, vq, Nf) end\n")
open('instr.lua','w').write(s)
