// Luau -> Lua5.1 lexical preprocessing: binary literals, underscores in numbers.
// The file is handled as latin1 so every byte survives unchanged (string literals may hold arbitrary bytes).
const fs=require('fs');
let s=fs.readFileSync(process.argv[2],'latin1'),o='',i=0;const n=s.length;
function longBracket(at){const m=/^\[(=*)\[/.exec(s.slice(at,at+256));if(!m)return -1;const e=s.indexOf(']'+m[1]+']',at+m[0].length);return e<0?n:e+m[1].length+2;}
while(i<n){const c=s[i];
 // comments: copied verbatim, so quotes or numbers inside them are never touched
 if(c=='-'&&s[i+1]=='-'){let e=-1;if(s[i+2]=='[')e=longBracket(i+2);if(e<0){e=s.indexOf('\n',i);if(e<0)e=n;}o+=s.slice(i,e);i=e;continue;}
 if(c=='"'||c=="'"){let j=i+1;while(j<n&&s[j]!=c&&s[j]!='\n'){if(s[j]=='\\')j++;j++;}o+=s.slice(i,Math.min(j+1,n));i=j+1;continue;}
 if(c=='['&&(s[i+1]=='['||s[i+1]=='=')){const e=longBracket(i);if(e>=0){o+=s.slice(i,e);i=e;continue;}}
 if(/[A-Za-z_]/.test(c)){const m=/^[A-Za-z_0-9]+/.exec(s.slice(i,i+256));o+=m[0];i+=m[0].length;continue;}
 if(/[0-9]/.test(c)||(c=='.'&&/[0-9]/.test(s[i+1]||''))){
  const m=/^(0[bB][01_]+|0[xX][0-9a-fA-F_]+|[0-9_]*\.?[0-9_]*([eE][+-]?[0-9_]+)?)/.exec(s.slice(i,i+400));
  let t=m[0].replace(/_/g,'');if(/^0[bB]/.test(t))t=BigInt('0b'+t.slice(2)).toString();
  o+=t;i+=m[0].length;continue;}
 o+=c;i++;}
fs.writeFileSync(process.argv[3],o,'latin1');
