// Luau -> Lua5.1 lexical preprocessing: binary literals, underscores in numbers
const fs=require('fs');
let s=fs.readFileSync(process.argv[2],'utf8'),o='',i=0,n=s.length;
while(i<n){const c=s[i];
 if(c=='"'||c=="'"){let j=i+1;while(s[j]!=c){if(s[j]=='\\')j++;j++;}o+=s.slice(i,j+1);i=j+1;continue;}
 if(c=='['&&(s[i+1]=='['||s[i+1]=='=')){let m=/^\[(=*)\[/.exec(s.slice(i,i+50));if(m){let e=s.indexOf(']'+m[1]+']',i);o+=s.slice(i,e+m[1].length+2);i=e+m[1].length+2;continue;}}
 if(/[A-Za-z_]/.test(c)){let m=/^[A-Za-z_0-9]+/.exec(s.slice(i,i+200));o+=m[0];i+=m[0].length;continue;}
 if(/[0-9]/.test(c)){let m=/^(0[bB][01_]+|0[xX][0-9a-fA-F_]+|[0-9_]*\.?[0-9_]*([eE][+-]?[0-9_]+)?)/.exec(s.slice(i,i+400));let t=m[0].replace(/_/g,'');if(/^0[bB]/.test(t))t=String(parseInt(t.slice(2),2));o+=t;i+=m[0].length;continue;}
 o+=c;i++;}
fs.writeFileSync(process.argv[3],o);
