#!/usr/bin/env bash
# Usage: tools/run.sh <obfuscated.lua> <workdir>
# Needs: node, python3 with `lupa` (pip install lupa).
set -euo pipefail
IN=$(realpath "$1"); W=$(realpath -m "$2"); T=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$W"; cd "$W"; cp "$T/shim.lua" .
export PYTHONPATH="$T"
node "$T/pre.js" "$IN" pre.lua            # Luau lexical quirks -> plain Lua
node "$T/beautify.js" pre.lua ast.json    # parse (patched luaparse: continue, +=)
node "$T/stage2.js"                       # fold constants, decrypt wrapper strings -> stage2.lua / stage2_jit.lua
python3 "$T/instr.py"                     # add dump hooks to the VM -> instr.lua
python3 "$T/dump.py" > /dev/null          # run the VM loader under LuaJIT, dump prototypes -> dump.json
node "$T/handlers.js" > /dev/null         # isolate each opcode handler -> handlers_used.txt
python3 "$T/disasm.py"                    # -> disasm.txt
python3 "$T/emit.py" out.lua              # decompile -> out.lua
echo "wrote $W/out.lua"
