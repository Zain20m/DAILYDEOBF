-- Luau compat shims for LuaJIT
local bit=require('bit')
local function u(x) x=x%4294967296 return x end
local function shl(a,n) if n<0 then n=-n if n>=32 then return 0 end return u(bit.rshift(a,n)) end if n>=32 then return 0 end return u(bit.lshift(a,n)) end
local function shr(a,n) if n<0 then n=-n if n>=32 then return 0 end return u(bit.lshift(a,n)) end if n>=32 then return 0 end return u(bit.rshift(a,n)) end
bit32={band=function(...) if select('#',...)==0 then return 4294967295 end return u(bit.band(...)) end,
 bor=function(...) if select('#',...)==0 then return 0 end return u(bit.bor(...)) end,
 bxor=function(...) if select('#',...)==0 then return 0 end return u(bit.bxor(...)) end,
 bnot=function(x) return u(bit.bnot(x)) end,lshift=shl,rshift=shr,
 arshift=function(a,n) if n<0 then return shl(a,-n) end if n>=32 then return u(a)>=2147483648 and 4294967295 or 0 end return u(bit.arshift(a,n)) end,
 lrotate=function(a,n) return u(bit.rol(a,n%32)) end,rrotate=function(a,n) return u(bit.ror(a,n%32)) end,
 extract=function(n,f,w) w=w or 1 if w>=32 then return u(bit.rshift(n,f)) end return u(bit.band(bit.rshift(n,f),2^w-1)) end,
 replace=function(n,v,f,w) w=w or 1 local m=w>=32 and 4294967295 or u(bit.lshift(2^w-1,f)) return u(bit.bor(bit.band(n,bit.bnot(m)),bit.band(bit.lshift(v,f),m))) end,
 btest=function(...) if select('#',...)==0 then return true end return bit.band(...)~=0 end,
 countlz=function(x) x=u(x) if x==0 then return 32 end local c=0 while x<2147483648 do x=x*2 c=c+1 end return c end,
 countrz=function(x) x=u(x) if x==0 then return 32 end local c=0 while x%2==0 do x=x/2 c=c+1 end return c end,
 byteswap=function(x) return u(bit.bswap(x)) end}
table.create=function(n,v) local t={} if v~=nil then for i=1,n do t[i]=v end end return t end
table.clear=function(t) for k in pairs(t) do t[k]=nil end end
table.pack=function(...) return {n=select('#',...),...} end
table.unpack=unpack
table.move=function(a,f,e,t,b) b=b or a if t<=f then for i=0,e-f do b[t+i]=a[f+i] end else for i=e-f,0,-1 do b[t+i]=a[f+i] end end return b end
table.find=function(t,v,i) for k=i or 1,#t do if t[k]==v then return k end end end
table.freeze=function(t) return t end
table.isfrozen=function() return false end
table.clone=function(t) local r={} for k,v in pairs(t) do r[k]=v end return setmetatable(r,getmetatable(t)) end
string.split=function(s,sep) sep=sep or ',' local r={} local i=1 while true do local a,b=string.find(s,sep,i,true) if not a then r[#r+1]=string.sub(s,i) break end r[#r+1]=string.sub(s,i,a-1) i=b+1 end return r end
math.clamp=function(x,a,b) return x<a and a or x>b and b or x end
math.sign=function(x) return x>0 and 1 or x<0 and -1 or 0 end
math.round=function(x) if x>=0 then return math.floor(x+0.5) end return math.ceil(x-0.5) end
typeof=typeof or function(x) return type(x) end
