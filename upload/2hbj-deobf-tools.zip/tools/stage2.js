const fs=require('fs');const {fold,gen,mkStr,isStr,sbytes}=require('./gen.js');
const yp=[...Buffer.from("<lNVdSW5Db8CU)KAIuLH$2_*3F!s-xytGmOaR{0efi}wk=oXM6EvP|(#nY`Q4z+9r7jTZh~1J%@&q^pcB?;g>")],Qd=[3,2,5,4,1];
const Ho={};yp.forEach((c,i)=>Ho[c]=i);
function ju(oK){const YY=[];let ul=0;while(ul+5<=oK.length){let Mg=0;for(let k=0;k<5;k++)Mg=Mg*85+(Ho[oK[ul+Qd[k]-1]]||0);
  YY.push(Math.floor(Mg/16777216)%256,Math.floor(Mg/65536)%256,Math.floor(Mg/256)%256,Mg%256);ul+=5;}
  const QV=YY[0]*16777216+YY[1]*65536+YY[2]*256+YY[3];return YY.slice(4,4+QV);}
function UQ(Vk,pW){const lH=13,RQ=pW.length,b=i=>pW[i-1];let ZU=b(7)||0,vj=b(15)||0,Nc=(RQ*14+vj)%256;const Il=[];
  for(let EW=0;EW<lH;EW++){ZU=(ZU*109+b(EW%RQ+1))%256;Il[EW]=ZU;}
  for(let EW=1;EW<=25;EW++){vj=((vj^b((EW+123)%RQ+1))+165)%256;ZU=(ZU*135+Nc)%256;Nc=(Nc+b(EW*ZU%RQ+1)+233)%256;Nc=(Nc+(ZU^vj)+ZU)%256;
    ZU=(ZU+b((vj+EW*3)%RQ+1))%256;let i1=EW*ZU%lH,i2=EW*vj%lH;[Il[i1],Il[i2]]=[Il[i2],Il[i1]];
    vj=(vj+Il[(EW*Nc+ZU)%lH])%256;ZU=(ZU+vj)%256;Il[(EW+ZU)%lH]=(Il[(EW+ZU)%lH]+b((EW*3+vj)%RQ+1))%256;Il[EW*Nc%lH]=(Il[EW*Nc%lH]*219+vj)%256;}
  const fS=[];
  for(let Ac=1;Ac<=Vk.length;Ac++){ZU=(ZU*55+222+b(Ac*190%RQ+1))%256;[ZU,Nc]=[Nc,ZU];vj=(vj+Il[(Ac*7+vj)%lH]+154)%256;
    let i1=(Ac*ZU+1)%lH,i2=(Ac*vj+1)%lH;[Il[i1],Il[i2]]=[Il[i2],Il[i1]];[ZU,Nc]=[Nc,ZU];ZU=(ZU+b((vj+Ac*3)%RQ+1))%256;
    Il[(Ac+Nc)%lH]=(Il[(Ac+Nc)%lH]+ZU*vj)%256;Il[(Ac+ZU)%lH]=(Il[(Ac+ZU)%lH]+b((Ac*3+vj)%RQ+1))%256;
    fS.push(Vk[Ac-1]^((ZU+vj+Nc+Il[(ZU*3+vj)%lH])%256));}
  return fS;}
function gX(s){const o=[];let i=0;while(i<s.length){if(s[i]<128)o.push(s[i++]);else{o.push(((s[i]-192)*64+(s[i+1]-128))&255);i+=2;}}return o;}
const call=(n,name,k)=>n.type=='CallExpression'&&n.base.type=='Identifier'&&n.base.name==name&&n.arguments.length==k&&n.arguments.every(isStr);
const ast=JSON.parse(fs.readFileSync('ast.json'));
fold(ast,{charFns:new Set(['NE']),hook(n){
  if(call(n,'ju',1))return mkStr(ju(sbytes(n.arguments[0])));
  if(call(n,'UQ',2))return mkStr(UQ(sbytes(n.arguments[0]),sbytes(n.arguments[1])));
  if(call(n,'gX',1))return mkStr(gX(sbytes(n.arguments[0])));
}});
fs.writeFileSync('stage2.lua',gen(ast,'luau'));fs.writeFileSync('stage2_jit.lua',gen(ast,'jit'));
