DAILYDEOBF ENGINE IMPORT BUNDLE

Contents:
- deobfuscators/: unique engines and adapters from the supplied old bot archive.
- luast-engine/: LUAST v1.0.1 source engine.
- luraph-v15.2-engine/: the separately supplied Luraph v15.2 engine.

This bundle intentionally omits old bot.js, .env, tokens, databases, user data,
duplicate IronBrew 2 / IronVeil / Luraph v14-v15 engines, and the bundled JRE.

IMPORTANT:
This is an engine-source import bundle, not yet a completed DAILYDEOBF integration.
The bot still needs its adapter/dispatch wiring and runtime checks before these
engines appear in the Discord picker. Upload this archive to the DAILYDEOBF
repository under upload/DAILYDEOBF_Engine_Import.zip so the integration can
install the sources and wire the selected engines without replacing the bot.
