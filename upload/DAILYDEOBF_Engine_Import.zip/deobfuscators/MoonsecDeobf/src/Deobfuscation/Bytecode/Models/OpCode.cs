﻿namespace MoonsecDeobfuscator.Bytecode.Models;

public enum OpCode
{

    Move,

    LoadK,

    LoadBool,

    LoadNil,

    GetUpval,

    GetGlobal,

    GetTable,

    SetGlobal,

    SetUpval,

    SetTable,

    NewTable,

    Self,

    Add,

    Sub,

    Mul,

    Div,

    Mod,

    Pow,

    Unm,

    Not,

    Len,

    Concat,

    Jmp,

    Eq,

    Lt,

    Le,

    Test,

    TestSet,

    Call,

    TailCall,

    Return,

    ForLoop,

    ForPrep,

    TForLoop,

    SetList,

    Close,

    Closure,

    VarArg,

    Unknown
}
