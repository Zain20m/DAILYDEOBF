// === PASTE into requestPinnedAddress (replace existing headers = { ... }) ===
const {
  requiresRobloxUserAgent,
  headersForScriptHost,
  ROBLOX_UA,
} = require('./roblox-ua');

// inside requestPinnedAddress, after method is known:
const headers = {
  ...headersForScriptHost(url, options.headers || {}),
  'accept-encoding': options.compressed ? 'gzip, deflate, br' : 'identity',
  connection: 'close',
  ...(method === 'PROPFIND' ? { depth: '0' } : {}),
};
if (requiresRobloxUserAgent(url)) {
  headers['user-agent'] = ROBLOX_UA;
}
