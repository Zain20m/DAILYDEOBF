# Fix Daily Deobf: LuaProtect CDN 403

## Cause (confirmed)

```text
Chrome UA  → HTTP 403  body: "-- This loader only works inside Roblox."
Roblox/WinInet → HTTP 200  full stub
```

Your bot’s `fetchPublicText` / `requestPinnedAddress` defaults to a **Chrome** User-Agent, so `cdn.luaprotect.dev` always 403s and shows:

`⚠️ Original URL download error`

## Fix (minimal)

### 1) Add file `roblox-ua.js` (included in this ZIP)

### 2) In bot entry (same folder as the module):

```js
const {
  requiresRobloxUserAgent,
  headersForScriptHost,
  isRobloxOnlyLoaderBody,
  ROBLOX_UA,
} = require('./roblox-ua');
```

### 3) In `requestPinnedAddress` — replace the default headers object

**Before:** hard-coded Chrome `user-agent`

**After:**

```js
const headers = {
  ...headersForScriptHost(url, options.headers || {}),
  ...(method === 'PROPFIND' ? { depth: '0' } : {}),
  'accept-encoding': options.compressed ? 'gzip, deflate, br' : 'identity',
  connection: 'close',
};
// options.headers already merged inside headersForScriptHost;
// do not let a Chrome UA override Roblox hosts:
if (requiresRobloxUserAgent(url)) {
  headers['user-agent'] = ROBLOX_UA;
}
```

### 4) In `fetchPublicText` 403 handler

After reading `rawErrorBody`, add:

```js
if (response.status === 403 && isRobloxOnlyLoaderBody(rawErrorBody)) {
  // Should not happen if step 3 is applied; if it does, message is accurate:
  throw new Error(
    'HTTP 403 from ' + current.hostname +
    ': loader requires User-Agent Roblox/WinInet. ' +
    'Update the bot fetcher (roblox-ua.js). Response: ' +
    rawErrorBody.replace(/\s+/g, ' ').trim()
  );
}
```

### 5) Restart the bot

Then `.deobf` with:

```text
loadstring(game:HttpGet("https://cdn.luaprotect.dev/u/8fca78/ol1GX-7CVfV0fyQz"))()
```

You should **not** see `Original URL download error` for this host.

## Also apply to runner-body

Same UA for:

- `https://exec.luaprotect.dev/api/runner-body/...`

`requiresRobloxUserAgent` already matches `*.luaprotect.dev`.

## Verify outside Discord

```bash
# fails
curl -A "Mozilla/5.0 ..." -i "https://cdn.luaprotect.dev/u/8fca78/ol1GX-7CVfV0fyQz" | head
# works
curl -A "Roblox/WinInet" -i "https://cdn.luaprotect.dev/u/8fca78/ol1GX-7CVfV0fyQz" | head
```
