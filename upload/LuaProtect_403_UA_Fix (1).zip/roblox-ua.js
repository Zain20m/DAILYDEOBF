'use strict';

/**
 * Fix: cdn.luaprotect.dev returns HTTP 403 + "-- This loader only works inside Roblox."
 * when User-Agent is a normal browser. Roblox/WinInet returns 200.
 */

const ROBLOX_UA = 'Roblox/WinInet';
const BROWSER_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function hostnameOf(urlLike) {
  try {
    return new URL(String(urlLike)).hostname.toLowerCase();
  } catch {
    return '';
  }
}

/** Hosts that gate on Roblox-like User-Agent */
function requiresRobloxUserAgent(urlLike) {
  const h = hostnameOf(urlLike);
  if (!h) return false;
  return (
    h === 'cdn.luaprotect.dev' ||
    h === 'exec.luaprotect.dev' ||
    h === 'api.luaprotect.dev' ||
    h.endsWith('.luaprotect.dev') ||
    h.includes('luarmor') ||
    h.includes('vantarmor') ||
    h.includes('luavify') ||
    /(?:^|\.)scripts?\./.test(h)
  );
}

function isRobloxOnlyLoaderBody(body) {
  return /only works inside Roblox/i.test(String(body || ''));
}

/**
 * Headers for a GET of script/loader content.
 * Always prefer Roblox UA for LuaProtect-family hosts.
 */
function headersForScriptHost(urlLike, extra = {}) {
  const base = requiresRobloxUserAgent(urlLike)
    ? {
        'user-agent': ROBLOX_UA,
        accept: '*/*',
        'cache-control': 'no-cache',
        pragma: 'no-cache',
      }
    : {
        'user-agent': BROWSER_UA,
        accept: 'text/plain, text/*, application/luau, application/javascript, application/octet-stream, application/json, */*;q=0.8',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'no-cache',
        pragma: 'no-cache',
      };
  // lower-case keys to match bot style
  const out = { ...base };
  for (const [k, v] of Object.entries(extra || {})) {
    if (v == null) continue;
    out[String(k).toLowerCase()] = String(v);
  }
  // Force Roblox UA even if caller passed Chrome
  if (requiresRobloxUserAgent(urlLike)) {
    out['user-agent'] = ROBLOX_UA;
  }
  return out;
}

/**
 * If a 403 body says Roblox-only, return a clear retry hint.
 */
function robloxGate403Message(hostname, body) {
  if (!isRobloxOnlyLoaderBody(body)) return null;
  return (
    'HTTP 403 from ' + hostname + ': host requires a Roblox User-Agent. ' +
    'Retry with User-Agent: Roblox/WinInet (not Chrome). Body: ' +
    String(body).replace(/\s+/g, ' ').trim().slice(0, 120)
  );
}

module.exports = {
  ROBLOX_UA,
  BROWSER_UA,
  requiresRobloxUserAgent,
  isRobloxOnlyLoaderBody,
  headersForScriptHost,
  robloxGate403Message,
};
