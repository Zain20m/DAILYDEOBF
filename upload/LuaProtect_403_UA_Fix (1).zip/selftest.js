const assert = require('assert');
const m = require('./roblox-ua');
assert.strictEqual(m.requiresRobloxUserAgent('https://cdn.luaprotect.dev/u/x/y'), true);
assert.strictEqual(m.requiresRobloxUserAgent('https://github.com/x'), false);
assert.strictEqual(m.headersForScriptHost('https://cdn.luaprotect.dev/u/x/y')['user-agent'], 'Roblox/WinInet');
assert.strictEqual(m.isRobloxOnlyLoaderBody('-- This loader only works inside Roblox.\n'), true);
console.log('ok');
