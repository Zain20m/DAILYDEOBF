# Luraph v15.1 Deobfuscator (Discord pack)

Recover readable Luau from Luraph v15 / v15.1 protected scripts.

## Requirements
- Node.js 18+
- Python 3.10+
- Linux or Windows (binaries included)

## Quick start
```bash
# one-shot (Discord-friendly)
./discord_run.sh path/to/script.lua out.luau

# or directly
cd luraph-v15.1-engine
node deob.js --plugin luraph_v15 -o out.luau path/to/script.lua
```

## Game-locked scripts
If output is only a small anti-tamper shell, pass the target GameId:
```bash
node deob.js --plugin luraph_v15 \
  --cfg-json '{"__superz_game_id":UNIVERSE_ID,"__superz_place_id":PLACE_ID}' \
  -o out.luau script.lua
```
Universe ID from: `https://apis.roblox.com/universes/v1/places/<PlaceId>/universe`

## Options
| Flag | Default | Meaning |
|------|---------|---------|
| `--no-devirt` | off | Behaviour trace only (fast) |
| `--timeout N` | 120 | Hard seconds per Luau pass |
| `--budget N` | 45 | Soft sandbox budget |
| `--debug` | off | Keep intermediate files |
| `--cfg-json` | — | Extra harness config (GameId, etc.) |

Env:
- `DEOB_FAST=1` — single Python candidate (default in this pack; avoids OOM)
- `DEOB_PY_CANDIDATES=python:1,python:2` — best-of-N if you have RAM

## Layout
```
discord_run.sh              # wrapper
luraph-v15.1-engine/
  deob.js                   # entry
  bin/luau, bin/luau-ast    # runtimes
  runtime/envlog.luau       # Roblox sandbox
  core/                     # Python lifter
  samples_v15.1_deobfuscated/
```

## Notes
- Micro samples deobfuscate to tiny programs (that is correct).
- Large hubs may need GameId + several minutes for the Python lift.
- Safety: review recovered source before running in any game client.
