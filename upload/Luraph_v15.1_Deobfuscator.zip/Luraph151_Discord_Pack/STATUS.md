# Pack status

## Fixed in this build
1. root_callee null — falls back to CHAIN.rootCallee, top emit, then max __PID
2. DEOB_FAST=1 default — single Python candidate (avoids multi-seed OOM)
3. discord_run.sh — produces output; copies bins to /tmp for noexec FS
4. anti-tamper TRIGGER isolation + keep prior trace on timeout
5. Path2D offline model + Studio cache replay

## Known limits
- Full Python lift of large hubs can take minutes / high RAM; use --no-devirt for fast trace
- Game-locked scripts need --cfg-json '{"__superz_game_id":N}'
- Micro samples correctly deobfuscate to tiny sources

## Verified
- Trace mode: all 7 Zain20m v15.1 samples finish
- Samples 1-5 full deobfuscated sources in results_v15.1/
