#!/usr/bin/env bash
# Discord-friendly Luraph v15.1 runner
# Usage: ./discord_run.sh input.lua [output.luau]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ENGINE="$ROOT/luraph-v15.1-engine"
export DEOB_FAST="${DEOB_FAST:-1}"
export DEOB_PY_CANDIDATES="${DEOB_PY_CANDIDATES:-python:1}"
# Prefer /tmp executable copy (noexec mounts)
if [ -x /tmp/l151_engine_bin/luau ]; then
  :
else
  mkdir -p /tmp/l151_engine_bin
  cp -f "$ENGINE/bin/luau" /tmp/l151_engine_bin/luau 2>/dev/null || true
  cp -f "$ENGINE/bin/luau-ast" /tmp/l151_engine_bin/luau-ast 2>/dev/null || true
  chmod +x /tmp/l151_engine_bin/luau /tmp/l151_engine_bin/luau-ast 2>/dev/null || true
fi
IN="${1:?usage: discord_run.sh input.lua [output.luau]}"
OUT="${2:-./deobfuscated_output.luau}"
mkdir -p "$(dirname "$OUT")"
cd "$ENGINE"
node deob.js --plugin luraph_v15 --debug --timeout 120 --budget 45 \
  -o "$OUT" "$IN" || true
# Always leave a non-empty result if possible
if [ ! -s "$OUT" ]; then
  TRACE="${OUT%.luau}_trace.luau"
  if [ -s "$TRACE" ]; then cp -f "$TRACE" "$OUT"; fi
fi
if [ -s "$OUT" ]; then
  echo "[+] wrote $OUT ($(wc -c < "$OUT") bytes)"
else
  echo "[!] no output produced" >&2
  exit 1
fi
