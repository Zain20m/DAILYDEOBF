# Luraph v15.1 Deobfuscator (fixed engine)

Standalone deobfuscator for **Luraph v15 / v15.1** Luau scripts.

## Quick start
```bash
# Linux / macOS
chmod +x discord_run.sh luraph-v15.1-engine/bin/*
./discord_run.sh path/to/script.lua out.luau

# or
cd luraph-v15.1-engine
node deob.js --plugin luraph_v15 -o out.luau path/to/script.lua
```

Needs: **Node.js 18+**, **Python 3.10+**

## What this build fixes
- `root_callee` null (fallback to emit / max proto id)
- Default `DEOB_FAST=1` (avoids multi-candidate OOM)
- Anti-tamper TRIGGER isolation + keep prior trace on timeout
- `discord_run.sh` copies bins to `/tmp` for noexec filesystems
- Auto **luaclean** beautify on large outputs (strips pure junk statements)

## Game-locked scripts
```bash
node luraph-v15.1-engine/deob.js --plugin luraph_v15 \
  --cfg-json '{"__superz_game_id":UNIVERSE_ID,"__superz_place_id":PLACE_ID}' \
  -o out.luau script.lua
```
Universe ID: `https://apis.roblox.com/universes/v1/places/<PlaceId>/universe`

## Notes
- Micro / checksum samples deobfuscate to tiny sources — that is correct.
- Large hubs need time + RAM for the Python lift; use `--no-devirt` for a fast behaviour trace.
- Review recovered source before running in any client.
