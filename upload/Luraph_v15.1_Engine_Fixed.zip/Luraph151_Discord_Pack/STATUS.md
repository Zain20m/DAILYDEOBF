# Engine status (replacement build)

Replaces stock v15.1 engine packs with this fixed tree.

Fixed:
1. root_callee null → CHAIN.rootCallee / top emit / max __PID
2. DEOB_FAST=1 default
3. discord_run.sh + /tmp bin staging
4. anti-tamper TRIGGER + timeout keeps prior body
5. optional luaclean post-pass on large outputs

Verified: trace mode on Zain20m v15.1 samples 1–7; full sources for regression samples 1–5 in results_v15.1/
