#!/usr/bin/env bash
# Luraph v15.1 Discord runner (fixed engine)
# Usage: ./discord_run.sh input.lua [output.luau]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
ENGINE="$ROOT/luraph-v15.1-engine"
export DEOB_FAST="${DEOB_FAST:-1}"
export DEOB_PY_CANDIDATES="${DEOB_PY_CANDIDATES:-python:1}"

# Prefer /tmp binaries (noexec mounts)
BINDIR="/tmp/l151_engine_bin"
mkdir -p "$BINDIR"
if [ ! -x "$BINDIR/luau" ]; then
  cp -f "$ENGINE/bin/luau" "$BINDIR/luau" 2>/dev/null || true
  cp -f "$ENGINE/bin/luau-ast" "$BINDIR/luau-ast" 2>/dev/null || true
  chmod +x "$BINDIR/luau" "$BINDIR/luau-ast" 2>/dev/null || true
fi

IN="${1:?usage: discord_run.sh input.lua [output.luau]}"
OUT="${2:-./deobfuscated_output.luau}"
mkdir -p "$(dirname "$OUT")"
ABS_IN="$(cd "$(dirname "$IN")" && pwd)/$(basename "$IN")"
ABS_OUT="$(cd "$(dirname "$OUT")" 2>/dev/null && pwd)/$(basename "$OUT")" || ABS_OUT="$OUT"

cd "$ENGINE"
set +e
node deob.js --plugin luraph_v15 --debug --timeout 120 --budget 45 \
  -o "$ABS_OUT" "$ABS_IN"
RC=$?
set -e

# Auto-beautify with luaclean when we have real source (not just a tiny trace)
if [ -s "$ABS_OUT" ] && [ -x "$BINDIR/luau-ast" ] && [ -f "$ENGINE/luaclean.py" ]; then
  BYTES=$(wc -c < "$ABS_OUT")
  if [ "$BYTES" -gt 2000 ]; then
    CLEAN="${ABS_OUT%.luau}_clean.luau"
    if python3 "$ENGINE/luaclean.py" "$BINDIR/luau-ast" "$ABS_OUT" "$CLEAN" 2>/dev/null; then
      if [ -s "$CLEAN" ]; then
        mv -f "$CLEAN" "$ABS_OUT"
        echo "[*] luaclean applied"
      fi
    fi
  fi
fi

if [ -s "$ABS_OUT" ]; then
  echo "[+] wrote $ABS_OUT ($(wc -c < "$ABS_OUT") bytes)"
  exit 0
fi
echo "[!] no output produced" >&2
exit 1
