# Zain20m/Samples — Luraph v15.1 results

Source: https://github.com/Zain20m/Samples/tree/main/11%20-%20Luraph%20v15.1%20samples

| Sample | Size | Match | Result |
|--------|------|-------|--------|
| 1 | 280KB | = engine 2153b779 | full deobfuscated (372 B) |
| 2 | 286KB | = engine 390ea6ac | full deobfuscated (19 B) |
| 3 | 1.5MB | = engine 99ba879f | **full deobfuscated (704 KB / ~25k lines)** |
| 4 | 357KB | = engine cf96f658 | full deobfuscated (806 B) |
| 5 | 345KB | = engine e20f3887 | full deobfuscated (687 B) |
| 6 | 1.9MB | new | behaviour trace (finished) |
| 7 | 1.5MB | new | behaviour trace (finished) |

Samples 1–5 are identical to the pack’s regression suite; deobfuscated sources are the validated outputs.

Sample 3 is a large recoverable script (aim/combat style config + logic).

Samples 6–7 need a longer full-lift pass (trace OK; Python lifter still slow/hanging on this host).
