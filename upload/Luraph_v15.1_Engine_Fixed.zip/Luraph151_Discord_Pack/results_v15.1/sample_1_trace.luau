 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(786, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 280, 0, 144)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.0625, -10, 0.0625, 4), UDim2.new(0, 5, 0, -2), UDim2.new(0, -8, 0, -5)), Path2DControlPoint.new(UDim2.new(0.3125, -2, 0.125, 5), UDim2.new(-0.125, -2, 0, 6), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, 0, 0.125, 2), UDim2.new(0, -2, -0.0625, -2), UDim2.new(0, -6, -0.125, 5)), Path2DControlPoint.new(UDim2.new(0, 0, 0, -4), UDim2.new(0, 3, 0, -7), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, -9, 0.25, 7), UDim2.new(-0.125, 2, 0, 7), UDim2.new(0, 1, -0.125, -4)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.93333333730697632)
 
Path2D2:GetPositionOnCurve(0.23076923191547394)
 
Path2D2:GetPositionOnCurve(0.8571428656578064)
 
Path2D2:GetPositionOnCurve(0.375)
 
Path2D2:GetTangentOnCurve(0.75)
 
Path2D2:GetTangentOnCurve(0.3125)
 
Path2D2:GetTangentOnCurve(0.3333333432674408)
 
Path2D2:GetTangentOnCurve(0.45454546809196472)
 
Path2D2:GetPositionOnCurveArcLength(0.1666666716337204)
 
Path2D2:GetPositionOnCurveArcLength(0.46666666865348816)
 
Path2D2:GetPositionOnCurveArcLength(0.18181818723678589)
 
Path2D2:GetTangentOnCurveArcLength(0.375)
 
Path2D2:GetTangentOnCurveArcLength(0.66666668653488159)
 
ScreenGui2:Destroy()
 
local connection = game.AttributeChanged:Connect(function(attribute)
end)
 
connection:Disconnect()
 
local connection2 = workspace.AttributeChanged:Connect(function(attribute2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.AttributeChanged:Connect(function(attribute3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.AttributeChanged:Connect(function(attribute4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "2100133505"
 
Folder:WaitForChild("2100133505")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.AttributeChanged:Connect(function(attribute5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.AttributeChanged:Connect(function(attribute6)
end)
 
connection6:Disconnect()
