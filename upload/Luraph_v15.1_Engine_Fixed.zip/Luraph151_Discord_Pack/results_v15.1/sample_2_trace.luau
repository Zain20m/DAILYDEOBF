 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(657, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 231, 0, 240)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.5, 9, 0, -5), UDim2.new(0, 0, 0, 0), UDim2.new(-0.125, -7, -0.0625, 4)), Path2DControlPoint.new(UDim2.new(0, 8, 0, -2), UDim2.new(0.125, 6, 0, 1), UDim2.new(0, 2, 0, 0)), Path2DControlPoint.new(UDim2.new(0.125, -9, 0.1875, -9), UDim2.new(0, 0, 0, -1), UDim2.new(-0.0625, -1, 0, -6)), Path2DControlPoint.new(UDim2.new(0, 7, 0, 2), UDim2.new(0, 7, 0.125, 1), UDim2.new(0, -1, 0, 7)), Path2DControlPoint.new(UDim2.new(0.4375, 4, 0.125, -5), UDim2.new(0.125, -5, -0.125, -6), UDim2.new(0, 0, 0, 0)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.53846156597137451)
 
Path2D2:GetPositionOnCurve(0.61538463830947876)
 
Path2D2:GetTangentOnCurve(0.4285714328289032)
 
Path2D2:GetTangentOnCurve(0.25)
 
Path2D2:GetTangentOnCurve(0.625)
 
Path2D2:GetTangentOnCurve(0.090909093618392944)
 
Path2D2:GetPositionOnCurveArcLength(0.78571426868438721)
 
Path2D2:GetPositionOnCurveArcLength(0.8461538553237915)
 
Path2D2:GetPositionOnCurveArcLength(0.3333333432674408)
 
Path2D2:GetTangentOnCurveArcLength(0.10000000149011612)
 
Path2D2:GetTangentOnCurveArcLength(0.77777779102325439)
 
ScreenGui2:Destroy()
 
local connection = game.DescendantRemoving:Connect(function(descendant)
end)
 
connection:Disconnect()
 
local connection2 = workspace.DescendantRemoving:Connect(function(descendant2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.DescendantRemoving:Connect(function(descendant3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.DescendantRemoving:Connect(function(descendant4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "656759991"
 
Folder:WaitForChild("656759991")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.DescendantRemoving:Connect(function(descendant5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.DescendantRemoving:Connect(function(descendant6)
end)
 
connection6:Disconnect()
