 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(626, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 208, 0, 195)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0, -8, 0.25, 3), UDim2.new(0, -5, 0, 7), UDim2.new(0, 4, 0, -5)), Path2DControlPoint.new(UDim2.new(0.375, -1, 0, -7), UDim2.new(0, -5, 0, -3), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0.5, -1, 0.25, 0), UDim2.new(-0.125, 5, 0, 6), UDim2.new(0.0625, 4, 0, 6)), Path2DControlPoint.new(UDim2.new(0, -7, 0.25, 8), UDim2.new(0, 0, 0, 0), UDim2.new(0, 3, 0, -1)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.3571428656578064)
 
Path2D2:GetPositionOnCurve(0.066666670143604279)
 
Path2D2:GetPositionOnCurve(0.6875)
 
Path2D2:GetTangentOnCurve(0.8888888955116272)
 
Path2D2:GetTangentOnCurve(0.083333335816860199)
 
Path2D2:GetPositionOnCurveArcLength(0.75)
 
Path2D2:GetPositionOnCurveArcLength(0.3333333432674408)
 
Path2D2:GetPositionOnCurveArcLength(0.55555558204650879)
 
Path2D2:GetTangentOnCurveArcLength(0.93333333730697632)
 
Path2D2:GetTangentOnCurveArcLength(0.66666668653488159)
 
Path2D2:GetTangentOnCurveArcLength(0.83333331346511841)
 
ScreenGui2:Destroy()
 
local connection = game.AncestryChanged:Connect(function(child, parent)
end)
 
connection:Disconnect()
 
local connection2 = workspace.AncestryChanged:Connect(function(child2, parent2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.AncestryChanged:Connect(function(child3, parent3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.AncestryChanged:Connect(function(child4, parent4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "1240615383"
 
Folder:WaitForChild("1240615383")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.AncestryChanged:Connect(function(child5, parent5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.AncestryChanged:Connect(function(child6, parent6)
end)
 
connection6:Disconnect()
