 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(893, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 120, 0, 237)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.25, 9, 0, -5), UDim2.new(0, -5, 0, 3), UDim2.new(0, -1, 0, -7)), Path2DControlPoint.new(UDim2.new(0, 5, 0, 7), UDim2.new(-0.125, -1, 0, 3), UDim2.new(0, 4, -0.125, -6)), Path2DControlPoint.new(UDim2.new(0, -10, 0, -6), UDim2.new(0, 0, 0, 0), UDim2.new(0, 0, 0, 7)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.89999997615814209)
 
Path2D2:GetPositionOnCurve(0.69999998807907104)
 
Path2D2:GetPositionOnCurve(0.20000000298023224)
 
Path2D2:GetPositionOnCurve(0.20000000298023224)
 
Path2D2:GetTangentOnCurve(0.1111111119389534)
 
Path2D2:GetTangentOnCurve(0.46153846383094788)
 
Path2D2:GetPositionOnCurveArcLength(0.1428571492433548)
 
Path2D2:GetPositionOnCurveArcLength(0.25)
 
Path2D2:GetTangentOnCurveArcLength(0.3333333432674408)
 
Path2D2:GetTangentOnCurveArcLength(0.20000000298023224)
 
ScreenGui2:Destroy()
 
local connection = game.ChildRemoved:Connect(function(child)
end)
 
connection:Disconnect()
 
local connection2 = workspace.ChildRemoved:Connect(function(child2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.ChildRemoved:Connect(function(child3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.ChildRemoved:Connect(function(child4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "493691678"
 
Folder:WaitForChild("493691678")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.ChildRemoved:Connect(function(child5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.ChildRemoved:Connect(function(child6)
end)
 
connection6:Disconnect()
