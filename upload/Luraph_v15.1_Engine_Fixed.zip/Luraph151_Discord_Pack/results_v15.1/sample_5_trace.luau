 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(326, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 294, 0, 276)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.5, -5, 0.0625, -10), UDim2.new(-0.125, -7, 0, 7), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0.5, 4, 0.0625, -8), UDim2.new(0, 0, 0, 0), UDim2.new(0.125, 6, 0, -5)), Path2DControlPoint.new(UDim2.new(0.5, -9, 0, -4), UDim2.new(0, 0, 0, 3), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0.375, 3, 0, -10), UDim2.new(0, -3, 0, -2), UDim2.new(-0.125, -7, 0, -3)), Path2DControlPoint.new(UDim2.new(0.5, -9, 0, -10), UDim2.new(0, -8, 0, 2), UDim2.new(0.0625, -1, -0.0625, 6)), Path2DControlPoint.new(UDim2.new(0, -4, 0, 5), UDim2.new(0, 0, 0, 0), UDim2.new(0, -3, -0.125, 6)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.25)
 
Path2D2:GetPositionOnCurve(0.3333333432674408)
 
Path2D2:GetPositionOnCurve(0.57142859697341919)
 
Path2D2:GetTangentOnCurve(0.71428573131561279)
 
Path2D2:GetTangentOnCurve(0.3333333432674408)
 
Path2D2:GetPositionOnCurveArcLength(0.125)
 
Path2D2:GetPositionOnCurveArcLength(0.81818181276321411)
 
Path2D2:GetPositionOnCurveArcLength(0.30000001192092896)
 
Path2D2:GetTangentOnCurveArcLength(0.4285714328289032)
 
Path2D2:GetTangentOnCurveArcLength(0.80000001192092896)
 
Path2D2:GetTangentOnCurveArcLength(0.5)
 
ScreenGui2:Destroy()
 
local connection = game.ChildRemoved:Connect(function(child)
end)
 
connection:Disconnect()
 
local connection2 = workspace.ChildRemoved:Connect(function(child2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.ChildRemoved:Connect(function(child3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.ChildRemoved:Connect(function(child4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "1985220820"
 
Folder:WaitForChild("1985220820")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.ChildRemoved:Connect(function(child5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.ChildRemoved:Connect(function(child6)
end)
 
connection6:Disconnect()
