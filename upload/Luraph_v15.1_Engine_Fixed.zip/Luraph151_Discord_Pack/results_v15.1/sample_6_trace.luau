 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(883, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 246, 0, 148)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.5, 3, 0.375, -3), UDim2.new(0, 0, 0, 0), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, -1, 0, -7), UDim2.new(0, -2, 0, -5), UDim2.new(0, -3, -0.0625, -8)), Path2DControlPoint.new(UDim2.new(0, -2, 0.4375, 9), UDim2.new(0, -3, 0.0625, 7), UDim2.new(0, -7, 0, 0)), Path2DControlPoint.new(UDim2.new(0, -10, 0.25, -8), UDim2.new(0, 2, 0.125, -2), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, 1, 0, 6), UDim2.new(0, 0, 0, 0), UDim2.new(0.125, 1, 0, -5)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.5)
 
Path2D2:GetPositionOnCurve(0.66666668653488159)
 
Path2D2:GetPositionOnCurve(0.4285714328289032)
 
Path2D2:GetTangentOnCurve(0.625)
 
Path2D2:GetTangentOnCurve(0.4285714328289032)
 
Path2D2:GetTangentOnCurve(0.15384615957736969)
 
Path2D2:GetTangentOnCurve(0.3333333432674408)
 
Path2D2:GetPositionOnCurveArcLength(0.66666668653488159)
 
Path2D2:GetPositionOnCurveArcLength(0.5)
 
Path2D2:GetPositionOnCurveArcLength(0.3333333432674408)
 
Path2D2:GetTangentOnCurveArcLength(0.57142859697341919)
 
Path2D2:GetTangentOnCurveArcLength(0.57142859697341919)
 
Path2D2:GetTangentOnCurveArcLength(0.875)
 
ScreenGui2:Destroy()
 
local connection = game.Destroying:Connect(function(arg)
end)
 
connection:Disconnect()
 
local connection2 = workspace.Destroying:Connect(function(arg2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.Destroying:Connect(function(arg3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.Destroying:Connect(function(arg4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "1210941084"
 
Folder:WaitForChild("1210941084")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.Destroying:Connect(function(arg5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.Destroying:Connect(function(arg6)
end)
 
connection6:Disconnect()
 
warn("JNKIE: Environment compatibility check failed (PC-R01).")
