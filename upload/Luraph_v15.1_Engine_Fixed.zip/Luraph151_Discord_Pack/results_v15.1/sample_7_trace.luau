 
task.spawn(function(...)
	 
	task.wait(0)
	 
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
	 
end)
 
task.delay(339, function(...)
	 
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 265, 0, 136)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0, 5, 0.25, 0), UDim2.new(0, -3, 0, -5), UDim2.new(0, -4, 0.125, -1)), Path2DControlPoint.new(UDim2.new(0, 2, 0.125, -7), UDim2.new(0, 2, 0.0625, 7), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, 3, 0, 2), UDim2.new(0, 0, 0, -4), UDim2.new(-0.0625, -6, 0, 3)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.375)
 
Path2D2:GetPositionOnCurve(0.90909093618392944)
 
Path2D2:GetPositionOnCurve(0.1666666716337204)
 
Path2D2:GetPositionOnCurve(0.875)
 
Path2D2:GetTangentOnCurve(0.60000002384185791)
 
Path2D2:GetTangentOnCurve(0.5)
 
Path2D2:GetTangentOnCurve(0.57142859697341919)
 
Path2D2:GetPositionOnCurveArcLength(0.20000000298023224)
 
Path2D2:GetPositionOnCurveArcLength(0.75)
 
Path2D2:GetPositionOnCurveArcLength(0.75)
 
Path2D2:GetTangentOnCurveArcLength(0.3333333432674408)
 
Path2D2:GetTangentOnCurveArcLength(0.6875)
 
ScreenGui2:Destroy()
 
local connection = game.ChildAdded:Connect(function(child)
end)
 
connection:Disconnect()
 
local connection2 = workspace.ChildAdded:Connect(function(child2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.ChildAdded:Connect(function(child3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.ChildAdded:Connect(function(child4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "297869281"
 
Folder:WaitForChild("297869281")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.ChildAdded:Connect(function(child5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.ChildAdded:Connect(function(child6)
end)
 
connection6:Disconnect()
