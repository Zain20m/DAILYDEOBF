# Status

## Engine fixes in this pack
- `root_callee` no longer forced to null: falls back to CHAIN.rootCallee or top emit id (official sample: root 32, 38 protos).
- Driver: timeout keeps prior trace; optional `no_tamper_guard` escalation; nonempty output guarantee.
- envlog: bit32 unwrap, buffer anti-tamper undo, noteTrigger fallback.
- Optional: build patched Luau (`#number` → 0) via `build_luau.py` + patch `luaV_dolen` for number type (see TECHNICAL notes).

## This Discord sample (`input` ~1.4MB)
Hits main-thread Luraph integrity before VM protos register. Offline Path2D model answers 11 queries; integrity still trips. Likely needs:
- correct `game.GameId` via `--cfg-json '{"__superz_game_id":N,"__superz_place_id":N}'`, and/or
- Studio Path2D cache (`--studio` / recorded P2D file).

Official samples under `luraph-v15.1-engine/samples_v15.1_deobfuscated/` finish and emit protos.

```bash
./discord_run.sh script.lua out.luau
# game-locked:
node luraph-v15.1-engine/deob.js --plugin luraph_v15 --cfg-json '{"__superz_game_id":YOUR_ID}' -o out.luau script.lua
```
