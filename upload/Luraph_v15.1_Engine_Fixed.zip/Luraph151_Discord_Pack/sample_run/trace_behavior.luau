 
task.spawn(function(...)
	 
	task.wait(0)
end)
 
task.spawn(function(...)
end)
 
task.defer(function(...)
end)
 
task.delay(905, function(...)
end)
 
local ScreenGui2 = Instance.new("ScreenGui")
 
local Frame2 = Instance.new("Frame")
 
Frame2.Position = UDim2.new(0, 0, 0, 0)
 
Frame2.Size = UDim2.new(0, 259, 0, 107)
 
Frame2.Parent = ScreenGui2
 
local Path2D2 = Instance.new("Path2D")
 
Path2D2.Parent = Frame2
 
Path2D2:SetControlPoints({ Path2DControlPoint.new(UDim2.new(0.4375, 6, 0.3125, 4), UDim2.new(-0.125, 5, 0, -1), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0, 2, 0, 1), UDim2.new(0, 0, 0, 0), UDim2.new(0, 0, 0, 0)), Path2DControlPoint.new(UDim2.new(0.125, -5, 0.375, 4), UDim2.new(0.125, -8, 0, -1), UDim2.new(0, 5, 0, -7)), Path2DControlPoint.new(UDim2.new(0, 4, 0, 1), UDim2.new(0, -5, 0, 0), UDim2.new(0, 0, 0, 0)) })
 
Path2D2:GetLength()
 
Path2D2:GetPositionOnCurve(0.40000000596046448)
 
Path2D2:GetPositionOnCurve(0.23076923191547394)
 
Path2D2:GetTangentOnCurve(0.66666668653488159)
 
Path2D2:GetTangentOnCurve(0.18181818723678589)
 
Path2D2:GetTangentOnCurve(0.45454546809196472)
 
Path2D2:GetTangentOnCurve(0.60000002384185791)
 
Path2D2:GetPositionOnCurveArcLength(0.20000000298023224)
 
Path2D2:GetPositionOnCurveArcLength(0.25)
 
Path2D2:GetTangentOnCurveArcLength(0.5)
 
Path2D2:GetTangentOnCurveArcLength(0.90909093618392944)
 
ScreenGui2:Destroy()
 
local connection = game.ChildAdded:Connect(function(child)
end)
 
connection:Disconnect()
 
local connection2 = workspace.ChildAdded:Connect(function(child2)
end)
 
connection2:Disconnect()
 
local Folder = Instance.new("Folder")
 
local connection3 = Folder.ChildAdded:Connect(function(child3)
end)
 
connection3:Disconnect()
 
Folder:GetChildren()
 
Folder:Destroy()
 
local Folder2 = Instance.new("Folder", Folder)
 
local connection4 = Folder2.ChildAdded:Connect(function(child4)
end)
 
connection4:Disconnect()
 
Folder2.Name = "648024067"
 
Folder:WaitForChild("648024067")
 
Folder:Destroy()
 
Folder2:Destroy()
 
local HttpService = game:GetService("HttpService")
 
local connection5 = HttpService.ChildAdded:Connect(function(child5)
end)
 
connection5:Disconnect()
 
local RunService = game:GetService("RunService")
 
local connection6 = RunService.ChildAdded:Connect(function(child6)
end)
 
connection6:Disconnect()
