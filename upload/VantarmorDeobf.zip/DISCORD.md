# Discord cheat-sheet

## Share the pack
Upload **VantarmorDeobf.zip** in the channel/DM (small file).

## User sends
Their loadstring + key (as text is fine).

## You reply
1. “Save your paste as `paste.txt` next to `vantarmor_deobf.py`”
2. Run:

```bash
python3 vantarmor_deobf.py --paste-file paste.txt -o recovered.lua
```

3. “Open `recovered.lua` and review it before any execute.”

## No Python?
Send them `AI_INSTRUCTIONS.md` + their paste, and tell them to paste both into an AI chat that can do HTTP requests.

## Avoid Discord errors
- Prefer **file attachments** over huge code pastes (Discord message length limits).
- ZIP filename: `VantarmorDeobf.zip` (no special characters).
- If recovered source is large, attach `recovered.lua` as a file; don’t paste 30k chars in chat.
