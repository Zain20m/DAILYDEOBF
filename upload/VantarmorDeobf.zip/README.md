# Vantarmor Deob Pack

Fetch the **server-delivered Lua source** for scripts protected by Vantarmor-style loaders.

> **Safety:** Recovered scripts can be harmful (stealers, lag switches, account damage, etc.).
> **Always read the full source before running anything in a game or executor.**
> This tool only downloads what the Vantarmor API returns after a valid key — it does not vouch for the script.

---

## What you need

1. The user paste, usually:

```lua
script_key = "YOUR_KEY_HERE"
loadstring(game:HttpGet("https://vantarmor.up.railway.app/files/v1/loaders/HASH.lua"))()
```

2. Python 3.9+ (no extra packages)

---

## Quick start (local)

```bash
python3 vantarmor_deobf.py --paste-file paste.txt -o recovered.lua
```

Or inline:

```bash
python3 vantarmor_deobf.py --paste 'script_key="KEY"
loadstring(game:HttpGet("https://vantarmor.up.railway.app/files/v1/loaders/HASH.lua"))()' -o recovered.lua
```

Or flags:

```bash
python3 vantarmor_deobf.py \
  --loader-url "https://vantarmor.up.railway.app/files/v1/loaders/HASH.lua" \
  --key "YOUR_KEY" \
  -o recovered.lua
```

---

## Discord (easy, no bot required)

Discord has file size limits. This ZIP is small — upload the whole ZIP or just these files:

| File | Purpose |
|------|---------|
| `vantarmor_deobf.py` | The fetcher |
| `README.md` | Human instructions |
| `AI_INSTRUCTIONS.md` | Give this to an AI with the loadstring |
| `paste.example.txt` | Example paste format |

### Recommended flow for helpers / sellers / friends

1. Download this ZIP and extract it.
2. Create a file `paste.txt` with the **exact** loadstring + key the user sent.
3. Run:

```bash
python3 vantarmor_deobf.py --paste-file paste.txt -o recovered.lua
```

4. Open `recovered.lua`, **review it**, only then decide whether to share or run.

### If you only use Discord mobile

- Upload `paste.txt` + ask someone with Python to run the command, **or**
- Paste the loadstring into an AI chat and attach / paste `AI_INSTRUCTIONS.md` (see below).

---

## Using an AI to deobfuscate

1. Open a new AI chat.
2. Send **both**:
   - The contents of `AI_INSTRUCTIONS.md` (or attach this ZIP)
   - The user’s loadstring + key paste
3. Ask: “Follow AI_INSTRUCTIONS.md and recover the source.”
4. The AI should run or simulate the same protocol and return `recovered.lua`.
5. **You** still review the source before running in-game.

---

## Protocol (for developers)

```
GET  {base}/v1/a?s={hash}&key={key}&hwid={hwid}&rbxid={rbxid}

Response A:  !VANTARMOR:TOKEN\n{token}
  then POST {base}/v1/p  with body={token}, Content-Type: text/plain

Response B:  !VANTARMOR:CODE\n{lua source}

Errors:      !VANTARMOR:KEY_REQUIRED | KEY_INVALID | KEY_EXPIRED | ...
```

Loader URL shape:

```
https://<host>/files/v1/loaders/<hash>.lua
```

---

## Limits

- Requires a **valid script_key** when the script is not free-for-all.
- Does **not** unpack inner obfuscators (VM packers) inside the payload.
- Does **not** bypass HWID locks if the server enforces them for that key.
- Output is whatever the server returns — may still be obfuscated.

---

## License / use

For interoperability and analysis of scripts **you are authorized to run**.
Do not use this to attack third-party services or steal paid scripts you do not own.
