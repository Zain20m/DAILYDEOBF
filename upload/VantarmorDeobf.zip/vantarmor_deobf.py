#!/usr/bin/env python3
"""
Vantarmor Deob Helper
---------------------
Fetches the server-delivered Lua source for a Vantarmor-protected loader.

Protocol (matches official loader):
  GET  {base}/v1/a?s={hash}&key={key}&hwid={hwid}&rbxid={rbxid}
  -> !VANTARMOR:TOKEN\\n{token}   OR   !VANTARMOR:CODE\\n{source}
  POST {base}/v1/p   body=token, Content-Type: text/plain
  -> !VANTARMOR:CODE\\n{source}

This does NOT unpack third-party VMs inside the payload (Dailyfuscator etc.).
It only retrieves what Vantarmor returns after a valid key.
"""
from __future__ import annotations

import argparse
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DEFAULT_BASE = "https://vantarmor.up.railway.app"
UA = "Roblox/WinInet"

LOADER_RE = re.compile(
    r"https?://[^\s\"']+/files/v1/loaders/([a-fA-F0-9]{32,64})\.lua",
    re.I,
)
HASH_RE = re.compile(r"\b([a-fA-F0-9]{40}|[a-fA-F0-9]{64})\b")
KEY_RE = re.compile(
    r"""(?:script_key|getgenv\(\)\.script_key)\s*=\s*["']([^"']+)["']""",
    re.I,
)
# also: script_key = "..." on its own / .GET script_key = "..."
KEY_RE2 = re.compile(
    r"""script_key\s*=\s*["']([^"']+)["']""",
    re.I,
)


def http_get(url: str, timeout: float = 35.0) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


def http_post_text(url: str, body: str, timeout: float = 35.0) -> str:
    data = body.encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "User-Agent": UA,
            "Content-Type": "text/plain",
            "Accept": "*/*",
            "Content-Length": str(len(data)),
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


def parse_paste(text: str) -> tuple[str | None, str | None, str | None]:
    """Return (base_url or None, hash, key) from a user paste."""
    text = text.strip()
    base = None
    script_hash = None
    key = None

    m = LOADER_RE.search(text)
    if m:
        script_hash = m.group(1).lower()
        # recover base: scheme://host
        full = m.group(0)
        # strip /files/v1/loaders/...
        idx = full.lower().find("/files/v1/loaders/")
        if idx > 0:
            base = full[:idx]

    km = KEY_RE.search(text) or KEY_RE2.search(text)
    if km:
        key = km.group(1).strip()

    if not script_hash:
        # bare hash argument
        hm = HASH_RE.search(text)
        if hm:
            script_hash = hm.group(1).lower()

    return base, script_hash, key


def auth_and_fetch(
    base: str,
    script_hash: str,
    script_key: str,
    hwid: str = "va-deob-hwid-0001",
    rbxid: str = "1",
) -> str:
    base = base.rstrip("/")
    q = urllib.parse.urlencode(
        {
            "s": script_hash,
            "key": script_key,
            "hwid": hwid,
            "rbxid": rbxid,
        }
    )
    body = http_get(f"{base}/v1/a?{q}")
    body = body.replace("\r\n", "\n")

    # pure error line
    err = re.fullmatch(r"!VANTARMOR:([A-Z0-9_]+)[\n]?$", body.strip())
    if err:
        raise RuntimeError(f"auth rejected: {err.group(1)}")

    token_prefix = "!VANTARMOR:TOKEN\n"
    code_prefix = "!VANTARMOR:CODE\n"

    if body.startswith(token_prefix):
        token = body[len(token_prefix) :].strip()
        body = http_post_text(f"{base}/v1/p", token)
        body = body.replace("\r\n", "\n")

    err = re.fullmatch(r"!VANTARMOR:([A-Z0-9_]+)[\n]?$", body.strip())
    if err:
        raise RuntimeError(f"payload rejected: {err.group(1)}")

    if not body.startswith(code_prefix):
        raise RuntimeError(f"unexpected response (first 80 chars): {body[:80]!r}")

    return body[len(code_prefix) :]


def light_cleanup(src: str) -> str:
    src = src.replace("\r\n", "\n")
    if src.startswith("-- deob by prince"):
        src = "-- Recovered from Vantarmor delivery\n" + src[len("-- deob by prince") :].lstrip("\n")
    if not src.endswith("\n"):
        src += "\n"
    return src


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Fetch Lua source from a Vantarmor loader + script_key"
    )
    p.add_argument(
        "--paste",
        help='Raw paste containing script_key and loadstring(HttpGet("...loaders/HASH.lua"))',
    )
    p.add_argument("--paste-file", help="File containing the paste")
    p.add_argument("--base", default=None, help="API base (default: from loader URL or Vantarmor Railway)")
    p.add_argument("--hash", default=None, help="Script hash")
    p.add_argument("--key", default=None, help="script_key")
    p.add_argument("--loader-url", default=None, help="Full loader URL")
    p.add_argument("--hwid", default="va-deob-hwid-0001")
    p.add_argument("--rbxid", default="1")
    p.add_argument("-o", "--output", default="recovered.lua")
    args = p.parse_args(argv)

    paste = args.paste or ""
    if args.paste_file:
        paste = Path(args.paste_file).read_text(encoding="utf-8", errors="replace")
    if args.loader_url:
        paste = (paste + "\n" + args.loader_url).strip()

    base_from_paste, hash_from_paste, key_from_paste = parse_paste(paste)

    base = args.base or base_from_paste or DEFAULT_BASE
    script_hash = (args.hash or hash_from_paste or "").lower()
    key = args.key or key_from_paste

    if args.loader_url and not script_hash:
        m = LOADER_RE.search(args.loader_url)
        if m:
            script_hash = m.group(1).lower()
            if not args.base:
                idx = args.loader_url.lower().find("/files/v1/loaders/")
                if idx > 0:
                    base = args.loader_url[:idx]

    if not script_hash:
        print("error: missing script hash (loader URL or --hash)", file=sys.stderr)
        return 2
    if not key:
        print("error: missing script_key (--key or paste)", file=sys.stderr)
        return 2

    print(f"base = {base}")
    print(f"hash = {script_hash}")
    print(f"key  = {key[:4]}...{key[-4:]} ({len(key)} chars)")

    try:
        src = auth_and_fetch(base, script_hash, key, args.hwid, args.rbxid)
    except urllib.error.HTTPError as e:
        print(f"error: HTTP {e.code} {e.reason}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    src = light_cleanup(src)
    out = Path(args.output)
    out.write_text(src, encoding="utf-8")
    print(f"ok: wrote {len(src)} bytes -> {out}")
    print("WARNING: Review the source before running it in any game/executor.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
